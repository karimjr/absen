<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>General Dashboard Absensi</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
/* ================= RESET ================= */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

/* ================= ROOT ================= */
:root{
    --radius-lg:22px;
    --radius-md:16px;
    --shadow:0 18px 40px rgba(0,0,0,.18);
}

/* ================= BODY ================= */
body{
    font-family:'Segoe UI',system-ui,sans-serif;
    background:linear-gradient(135deg,#0ea5e9,#22d3ee);
    min-height:100vh;
    color:#fff;
}

/* ================= CONTAINER ================= */
.container{
    max-width:1250px;
    margin:auto;
    padding:30px 20px;
}

/* ================= NAVBAR ================= */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:20px 28px;
    background:rgba(255,255,255,.18);
    backdrop-filter:blur(10px);
    border-radius:var(--radius-lg);
    box-shadow:var(--shadow);
}
.navbar h1{
    font-size:22px;
}
.navbar span{
    font-size:14px;
    opacity:.85;
}

/* ================= HERO ================= */
.hero{
    margin:35px 0 25px;
}
.hero h2{
    font-size:34px;
    margin-bottom:6px;
}
.hero p{
    opacity:.9;
    max-width:520px;
}

/* ================= STATS ================= */
.stats{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    margin:30px 0;
}
.stat-card{
    background:#fff;
    color:#111;
    border-radius:var(--radius-md);
    padding:22px;
    box-shadow:var(--shadow);
}
.stat-card h3{
    font-size:30px;
}
.stat-card span{
    font-size:14px;
    color:#555;
}

/* ================= MENU ================= */
.menu{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
    gap:25px;
}

/* CARD = LINK */
.menu-card{
    display:block;
    background:#fff;
    color:#111;
    border-radius:24px;
    padding:30px 26px;
    box-shadow:var(--shadow);
    text-decoration:none;
    transition:.35s;
    position:relative;
    overflow:hidden;
}
.menu-card::before{
    content:"";
    position:absolute;
    inset:0;
    background:linear-gradient(135deg,transparent,rgba(0,0,0,.06));
    pointer-events:none;
}
.menu-card:hover{
    transform:translateY(-10px) scale(1.03);
}

.menu-card .icon{
    font-size:48px;
    margin-bottom:12px;
}
.menu-card h3{
    margin-bottom:6px;
}
.menu-card p{
    font-size:14px;
    color:#666;
    margin-bottom:22px;
}
.menu-card .btn{
    display:inline-block;
    padding:12px 22px;
    border-radius:14px;
    color:#fff;
    font-weight:600;
    font-size:14px;
}

/* ================= WARNA DIVISI ================= */
.hrga .icon{color:#0d9488;}
.hrga .btn{background:#0d9488;}

.hse .icon{color:#dc2626;}
.hse .btn{background:#dc2626;}

.produksi .icon{color:#16a34a;}
.produksi .btn{background:#16a34a;}

.fgexport .icon{color:#0f766e;}
.fgexport .btn{background:#0f766e;}

.rawmat .icon{color:#f97316;}
.rawmat .btn{background:#f97316;}

.workshop .icon{color:#6366f1;}
.workshop .btn{background:#6366f1;}

.semua .icon{color:#7c3aed;}
.semua .btn{background:#7c3aed;}

/* ================= FOOTER ================= */
.footer{
    margin:45px 0 15px;
    text-align:center;
    font-size:14px;
    opacity:.85;
}
</style>
</head>

<body>

<div class="container">

    <!-- NAVBAR -->
    <div class="navbar">
        <h1>📊 Sistem Absensi Terintegrasi</h1>
        <span>General Dashboard</span>
    </div>

    <!-- HERO -->
    <div class="hero">
        <h2>Selamat Datang 👋</h2>
        <p>Kelola absensi seluruh divisi perusahaan dalam satu dashboard terpusat.</p>
    </div>

    <!-- STATS -->
    <div class="stats">
        <div class="stat-card">
            <h3>6</h3>
            <span>Total Divisi</span>
        </div>
        <div class="stat-card">
            <h3>Online</h3>
            <span>Status Sistem</span>
        </div>
        <div class="stat-card">
            <h3>Realtime</h3>
            <span>Monitoring Absensi</span>
        </div>
    </div>

    <!-- MENU -->
    <div class="menu">

        <a href="rekap_semua.php" class="menu-card semua">
            <div class="icon">📊</div>
            <h3>Rekap Seluruh Divisi</h3>
            <p>Gabungan absensi semua divisi dalam satu halaman</p>
            <span class="btn">Lihat Rekap →</span>
        </a>

        <a href="absen_hrga/admin_rekap.php" class="menu-card hrga">
            <div class="icon">👥</div>
            <h3>Absensi HRGA</h3>
            <p>Human Resource & General Affair</p>
            <span class="btn">Masuk Dashboard →</span>
        </a>

        <a href="absen_hse/admin_rekap.php" class="menu-card hse">
            <div class="icon">🦺</div>
            <h3>Absensi HSE</h3>
            <p>Health, Safety & Environment</p>
            <span class="btn">Masuk Dashboard →</span>
        </a>

        <a href="absen_produksi/admin_rekap.php" class="menu-card produksi">
            <div class="icon">🏭</div>
            <h3>Absensi Produksi</h3>
            <p>Produksi & Operasional</p>
            <span class="btn">Masuk Dashboard →</span>
        </a>

        <a href="absen_fgexport/admin_rekap.php" class="menu-card fgexport">
            <div class="icon">🚢</div>
            <h3>Absensi F/G & Export</h3>
            <p>Finished Goods & Export</p>
            <span class="btn">Masuk Dashboard →</span>
        </a>

        <a href="absen_rawmat/admin_rekap.php" class="menu-card rawmat">
            <div class="icon">📦</div>
            <h3>Absensi Raw Material</h3>
            <p>Gudang & Bahan Baku</p>
            <span class="btn">Masuk Dashboard →</span>
        </a>

        <a href="absen_workshop/admin_rekap.php" class="menu-card workshop">
            <div class="icon">🔧</div>
            <h3>Absensi Workshop</h3>
            <p>Teknik & Maintenance</p>
            <span class="btn">Masuk Dashboard →</span>
        </a>

    </div>

    <!-- FOOTER -->
    <div class="footer">
        © <?= date('Y') ?> Sistem Absensi • Semua Divisi
    </div>

</div>

</body>
</html>