<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

if(!isset($_SESSION['counter'])){
    $_SESSION['counter'] = 0;
}
$_SESSION['counter']++;

echo "Session ID: " . session_id() . "<br>";
echo "Counter: " . $_SESSION['counter'] . "<br>";
echo "Save path: " . session_save_path() . "<br>";
echo "open_basedir: " . ini_get('open_basedir') . "<br>";
echo "Path writable? " . (is_writable(session_save_path()) ? "YA" : "TIDAK") . "<br>";