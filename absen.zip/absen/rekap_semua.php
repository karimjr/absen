<?php
/*
|--------------------------------------------------------------------------
| REKAP ABSENSI SELURUH DIVISI (VIEW ONLY, TANPA PASSWORD)
|--------------------------------------------------------------------------
| Letakkan file ini di folder root "absen/" (sejajar dengan index.php).
| Halaman ini membaca database tiap divisi secara terpisah lalu menggabungkan
| hasilnya. Tidak ada data yang diubah / ditulis ke database.
|
| Aturan hitung (justifikasi default, telat, pulang cepat, jam kerja) SAMA
| dengan admin_rekap.php di tiap divisi, sehingga angkanya konsisten.
|
| % Hadir = Hadir (maks. hari efektif per orang) / (Jumlah karyawan x Hari kerja efektif) x 100
| KPI kehadiran tercapai jika % Hadir >= $KPI_HADIR_MIN
|
| Sheet baru: MAN HOURS (matriks karyawan x tanggal berkode H/A/S/I/C/Off/DL)
*/

mysqli_report(MYSQLI_REPORT_OFF);

// ==========================================
// KONFIGURASI
// ==========================================
$DB_HOST = "localhost";
$DB_USER = "potensib_pbs";
$DB_PASS = "arsari-group";

$DIVISI = [
    'hrga'     => ['nama' => 'HRGA',         'full' => 'Human Resource & General Affair', 'db' => 'potensib_absen_hrga',     'folder' => 'absen_hrga',     'warna' => '#0d9488', 'ikon' => '👥'],
    'hse'      => ['nama' => 'HSE',          'full' => 'Health, Safety & Environment',    'db' => 'potensib_absen_hse',      'folder' => 'absen_hse',      'warna' => '#dc2626', 'ikon' => '🦺'],
    'produksi' => ['nama' => 'Produksi',     'full' => 'Produksi & Operasional',          'db' => 'potensib_absen_produksi', 'folder' => 'absen_produksi', 'warna' => '#16a34a', 'ikon' => '🏭'],
    'fge'      => ['nama' => 'F/G & Export', 'full' => 'Finished Goods & Export',         'db' => 'potensib_absen_fge',      'folder' => 'absen_fgexport', 'warna' => '#0f766e', 'ikon' => '🚢'],
    'rawmat'   => ['nama' => 'Raw Material', 'full' => 'Gudang & Bahan Baku',             'db' => 'potensib_absen_rawmat',   'folder' => 'absen_rawmat',   'warna' => '#f97316', 'ikon' => '📦'],
    'workshop' => ['nama' => 'Workshop',     'full' => 'Teknik & Maintenance',            'db' => 'potensib_absen_workshop', 'folder' => 'absen_workshop', 'warna' => '#6366f1', 'ikon' => '🔧'],
];

// ---- Pengaturan Man Hours (format template bulanan) ----
$MH_JAM_PER_HARI = 8;     // Total Jam Kerja = jumlah hari dihitung x jam ini (sesuai template: 24 H = 192 jam)
$MH_DL_DIHITUNG  = true;  // true = Dinas Luar (DL) ikut dihitung sebagai hari kerja

// kode => [warna latar, warna teks, keterangan]
// Setiap kode punya warna SENDIRI-SENDIRI (sama dengan warna di rekap harian):
//   A = merah pekat | T/PC/TP = oranye-pink-fuchsia | S = kuning | I = cyan | CT = biru | Off = hijau | DL = ungu
// T / PC / TP tetap dihitung sebagai HADIR (masuk ke Total H & Total Jam Kerja).
$MH_KODE = [
    'H'   => ['#ffffff', '#0f172a', 'Hadir'],
    'T'   => ['#fb923c', '#431407', 'Hadir - Telat'],
    'PC'  => ['#f9a8d4', '#831843', 'Hadir - Pulang Cepat'],
    'TP'  => ['#d946ef', '#ffffff', 'Hadir - Telat & Pulang Cepat'],
    'A'   => ['#dc2626', '#ffffff', 'Alpa'],
    'S'   => ['#fde047', '#713f12', 'Sakit'],
    'I'   => ['#67e8f9', '#155e75', 'Izin'],
    'CT'  => ['#93c5fd', '#1e3a8a', 'Cuti'],
    'Off' => ['#86efac', '#14532d', 'Off / Libur'],
    'DL'  => ['#d8b4fe', '#581c87', 'Dinas Luar'],
];
// kolom total di kanan (urutan seperti template, ditambah Telat & Pulang Cepat) + warna header masing-masing
$MH_URUT = ['H', 'T', 'PC', 'CT', 'S', 'I', 'A', 'DL'];
$MH_HEAD = [
    'H'  => ['#ffffff', '#0f172a'],
    'T'  => ['#fb923c', '#431407'],
    'PC' => ['#f9a8d4', '#831843'],
    'CT' => ['#93c5fd', '#1e3a8a'],
    'S'  => ['#fde047', '#713f12'],
    'I'  => ['#67e8f9', '#155e75'],
    'A'  => ['#dc2626', '#ffffff'],
    'DL' => ['#d8b4fe', '#581c87'],
];
$MH_HEAD_LABEL = ['T' => 'Telat', 'PC' => 'P. Cepat'];   // judul kolom total (selain "Total <kode>")
$MH_HADIR = ['H', 'T', 'PC', 'TP'];                       // semua kode yang dihitung hadir
$MH_HEAD_JAM = ['#22c55e', '#052e16'];

// ---- Pengaturan Karyawan Teladan (Best Employee) ----
// Skor awal tiap karyawan, lalu dikurangi sesuai tabel di bawah (nilai = pengurang per kejadian).
// Dinas Luar (DL) TIDAK mengurangi skor.
$BE_SKOR_AWAL = 100;
$BE_PENALTI = [
    'alpha'          => 5,  // per hari Alpa
    'cuti'           => 1,  // per hari Cuti
    'sakit'          => 2,  // per hari Sakit
    'izin'           => 2,  // per hari Izin
    'pulang_cepat'   => 1,  // per kali pulang cepat
    'telat'          => 1,  // per kali terlambat
    'tidak_clockout' => 0,  // ada Clock In tetapi tidak Clock Out (isi angka bila ingin ikut mengurangi)
];

// ---- Pengaturan KPI Kehadiran ----
// Hari kerja efektif dihitung OTOMATIS dari data: hari selain Minggu yang minimal ada satu karyawan absen (divisi mana pun).
// Hari tanpa satu pun absen (mis. libur nasional / cuti bersama) tidak dihitung, begitu juga hari yang belum terjadi.
$KPI_HADIR_MIN      = 85;  // target minimal % hadir

function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// ==========================================
// PARAMETER FILTER
// ==========================================
function validTanggal($s){
    return is_string($s) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $s) && strtotime($s) !== false;
}

$start = $_GET['start'] ?? '';
$end   = $_GET['end'] ?? '';
if (!validTanggal($start) || !validTanggal($end)) {
    $start = date('Y-m-01');
    $end   = date('Y-m-d');
}
if (strtotime($start) > strtotime($end)) { $tmp = $start; $start = $end; $end = $tmp; }

// batasi maksimal 366 hari agar server tidak berat
$MAX_HARI = 366;
if ((strtotime($end) - strtotime($start)) / 86400 > $MAX_HARI) {
    $start = date('Y-m-d', strtotime($end . " -{$MAX_HARI} days"));
}

$divisiPilih = $_GET['divisi'] ?? '';
if ($divisiPilih !== '' && !isset($DIVISI[$divisiPilih])) $divisiPilih = '';

$q    = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));

// ==========================================
// JAM KERJA & HITUNG TELAT / PULANG CEPAT
// ==========================================
$HARI_NAMA = [0=>'Minggu',1=>'Senin',2=>'Selasa',3=>'Rabu',4=>'Kamis',5=>'Jumat',6=>'Sabtu'];

function jamKerja($hari, $nama, $kodeDivisi){
    if ($hari === 'Minggu') return null;

    // Jadwal khusus hanya berlaku di HRGA (Susanti & Maulida)
    $khusus = false;
    if ($kodeDivisi === 'hrga') {
        $n = strtolower(trim($nama));
        foreach (['susanti', 'maulida'] as $nk) {
            if (strpos($n, $nk) !== false) { $khusus = true; break; }
        }
    }

    if ($khusus) {
        if ($hari === 'Jumat') return ['masuk' => '07:00:00', 'keluar' => '16:00:00'];
        if ($hari === 'Sabtu') return ['masuk' => '07:00:00', 'keluar' => '12:00:00'];
        return ['masuk' => '07:00:00', 'keluar' => '13:00:00'];
    }
    if ($hari === 'Jumat') return ['masuk' => '08:00:00', 'keluar' => '17:00:00'];
    if ($hari === 'Sabtu') return ['masuk' => '08:00:00', 'keluar' => '13:00:00'];
    return ['masuk' => '08:00:00', 'keluar' => '16:00:00'];
}

function detik($t){
    $p = explode(':', $t);
    return ((int)$p[0]) * 3600 + ((int)($p[1] ?? 0)) * 60 + (int)($p[2] ?? 0);
}

function hitungTelatCepat($hari, $masuk, $keluar, $nama, $kodeDivisi){
    $r = ['telat' => 0, 'cepat' => 0];
    $jam = jamKerja($hari, $nama, $kodeDivisi);
    if ($jam === null) return $r;

    if (!empty($masuk)) {
        $diff = (detik($masuk) - detik($jam['masuk'])) / 60;
        if ($diff > 0) $r['telat'] = (int)round($diff);
    }
    if (!empty($keluar)) {
        $diff = (detik($jam['keluar']) - detik($keluar)) / 60;
        if ($diff > 0) $r['cepat'] = (int)round($diff);
    }
    return $r;
}

function kategoriJ($j){
    $k = strtolower($j);
    if (in_array($k, ['sakit','izin','alpha','dinas','libur','cuti'], true)) return $k;
    if (in_array($k, ['normal','telat','pulang cepat','telat & pulang cepat'], true)) return '';
    return 'lainnya';
}

function counterBaru(){
    return ['karyawan'=>0,'hadir'=>0,'hadir_ef'=>0,'hari_kerja'=>0,'telat_kali'=>0,'telat_menit'=>0,
            'cepat_kali'=>0,'cepat_menit'=>0,'sakit'=>0,'izin'=>0,'alpha'=>0,'dinas'=>0,'cuti'=>0,'libur'=>0,'lainnya'=>0];
}

// Hari kerja efektif per orang untuk rentang tanggal + rinciannya.
// Efektif = tanggal (bukan Minggu) yang ada minimal satu karyawan clock in/out di divisi mana pun.
// Tidak terpengaruh filter nama / divisi, supaya pembagi tetap sama.
function hariEfektifDetail($start, $end){
    global $DB_HOST, $DB_USER, $DB_PASS, $DIVISI;
    $aktif = [];
    $berhasil = 0;
    $from = $start . ' 00:00:00';
    $to   = $end   . ' 23:59:59';

    foreach ($DIVISI as $cfg) {
        $conn = @new mysqli($DB_HOST, $DB_USER, $DB_PASS, $cfg['db']);
        if ($conn->connect_error) continue;
        $stmt = $conn->prepare("SELECT DISTINCT DATE(waktu) AS tgl FROM absensi
                                WHERE waktu BETWEEN ? AND ? AND status IN ('C/Masuk','C/Keluar')");
        if ($stmt) {
            $stmt->bind_param('ss', $from, $to);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($r = $res->fetch_assoc()) $aktif[$r['tgl']] = true;
            $stmt->close();
            $berhasil++;
        }
        $conn->close();
    }

    $hariIni = date('Y-m-d');
    $d = ['total'=>0, 'kalender'=>0, 'minggu'=>0, 'tanpa_absen'=>[], 'belum'=>0, 'fallback'=>($berhasil === 0)];

    for ($t = strtotime($start); $t <= strtotime($end); $t = strtotime('+1 day', $t)) {
        $tgl = date('Y-m-d', $t);
        $d['kalender']++;
        if ((int)date('w', $t) === 0) { $d['minggu']++; continue; }
        if ($d['fallback']) { $d['total']++; continue; }      // database gagal dibaca: semua non-Minggu dihitung
        if (isset($aktif[$tgl])) { $d['total']++; continue; }
        if ($tgl > $hariIni) $d['belum']++;
        else $d['tanpa_absen'][] = $tgl;
    }
    return $d;
}

// ==========================================
// MAN HOURS: KODE PER HARI
// ==========================================
function kodeMH($r){
    $j = strtolower(trim($r['j']));
    if ($j === 'alpha') return 'A';
    if ($j === 'sakit') return 'S';
    if ($j === 'izin')  return 'I';
    if ($j === 'cuti')  return 'CT';
    if ($j === 'libur') return 'Off';
    if ($j === 'dinas' || $j === 'dinas luar') return 'DL';
    if (!($r['masuk'] || $r['keluar'])) return 'A';
    if ($r['telat'] > 0 && $r['cepat'] > 0) return 'TP';
    if ($r['telat'] > 0) return 'T';
    if ($r['cepat'] > 0) return 'PC';
    return 'H';
}

// total tampilan per karyawan: H = semua kode hadir; T / PC ikut menghitung kejadian gabungan (TP)
function totalMH($cnt){
    global $MH_HADIR;
    $h = 0;
    foreach ($MH_HADIR as $k) $h += $cnt[$k];
    return ['H' => $h, 'T' => $cnt['T'] + $cnt['TP'], 'PC' => $cnt['PC'] + $cnt['TP'],
            'CT' => $cnt['CT'], 'S' => $cnt['S'], 'I' => $cnt['I'], 'A' => $cnt['A'], 'DL' => $cnt['DL']];
}

// ==========================================
// AMBIL DATA PER DIVISI
// ==========================================
function ambilDivisi($kode, $cfg, $start, $end, $q, &$error){
    global $DB_HOST, $DB_USER, $DB_PASS, $HARI_NAMA;

    $conn = @new mysqli($DB_HOST, $DB_USER, $DB_PASS, $cfg['db']);
    if ($conn->connect_error) {
        $error = $conn->connect_error;
        return null;
    }
    $conn->set_charset('utf8mb4');

    $from = $start . ' 00:00:00';
    $to   = $end   . ' 23:59:59';

    $sql = "SELECT no_id, nama, DATE(waktu) AS tanggal,
                   MIN(CASE WHEN status='C/Masuk'  THEN TIME(waktu) END) AS masuk,
                   MAX(CASE WHEN status='C/Keluar' THEN TIME(waktu) END) AS keluar,
                   COALESCE(NULLIF(MAX(justifikasi),''),'Normal') AS justifikasi
            FROM absensi
            WHERE waktu BETWEEN ? AND ?";
    if ($q !== '') $sql .= " AND (nama LIKE ? OR no_id LIKE ?)";
    $sql .= " GROUP BY no_id, nama, DATE(waktu)";

    $stmt = $conn->prepare($sql);
    if (!$stmt) { $error = $conn->error; $conn->close(); return null; }

    if ($q !== '') {
        $like = '%' . $q . '%';
        $stmt->bind_param('ssss', $from, $to, $like, $like);
    } else {
        $stmt->bind_param('ss', $from, $to);
    }
    $stmt->execute();
    $res = $stmt->get_result();

    $absenMap = [];
    $karyawan = [];
    while ($r = $res->fetch_assoc()) {
        $absenMap[$r['no_id'] . '|' . $r['tanggal']] = $r;
        $karyawan[$r['no_id']] = $r['nama'];
    }
    $stmt->close();
    $conn->close();

    // daftar tanggal
    $tanggalList = [];
    for ($t = strtotime($start); $t <= strtotime($end); $t = strtotime('+1 day', $t)) {
        $tanggalList[] = date('Y-m-d', $t);
    }

    // semua karyawan x semua tanggal (hari tanpa data = Alpha / Libur bila Minggu)
    $rows = [];
    foreach ($karyawan as $id => $nm) {
        foreach ($tanggalList as $tgl) {
            $key  = $id . '|' . $tgl;
            $hari = $HARI_NAMA[(int)date('w', strtotime($tgl))];

            if (isset($absenMap[$key])) {
                $masuk = $absenMap[$key]['masuk'];
                $keluar = $absenMap[$key]['keluar'];
                $j = trim($absenMap[$key]['justifikasi']);
            } else {
                $masuk = null; $keluar = null;
                $j = ($hari === 'Minggu') ? 'Libur' : 'Alpha';
            }

            $tc = hitungTelatCepat($hari, $masuk, $keluar, $nm, $kode);

            if ($j === 'Normal' && ($tc['telat'] > 0 || $tc['cepat'] > 0)) {
                if ($tc['telat'] > 0 && $tc['cepat'] > 0) $j = 'Telat & Pulang Cepat';
                elseif ($tc['telat'] > 0) $j = 'Telat';
                else $j = 'Pulang Cepat';
            }

            $rows[] = [
                'div' => $kode, 'no_id' => $id, 'nama' => $nm, 'tanggal' => $tgl, 'hari' => $hari,
                'masuk' => $masuk, 'keluar' => $keluar,
                'telat' => $tc['telat'], 'cepat' => $tc['cepat'], 'j' => $j,
            ];
        }
    }
    return $rows;
}

$targetDivisi = $divisiPilih !== '' ? [$divisiPilih => $DIVISI[$divisiPilih]] : $DIVISI;

$allRows  = [];
$errors   = [];
$perDiv   = [];
$perKar   = [];
$mh       = [];   // data man hours per karyawan

foreach ($targetDivisi as $kode => $cfg) {
    $err = '';
    $rows = ambilDivisi($kode, $cfg, $start, $end, $q, $err);
    $perDiv[$kode] = counterBaru();

    if ($rows === null) { $errors[$kode] = $err; continue; }

    foreach ($rows as $r) {
        $allRows[] = $r;

        $kk = $kode . '|' . $r['no_id'];
        if (!isset($perKar[$kk])) {
            $perKar[$kk] = counterBaru();
            $perKar[$kk]['div'] = $kode;
            $perKar[$kk]['no_id'] = $r['no_id'];
            $perKar[$kk]['nama'] = $r['nama'];
            $perKar[$kk]['karyawan'] = 1;
            $perDiv[$kode]['karyawan']++;
        }

        foreach ([&$perKar[$kk], &$perDiv[$kode]] as &$c) {
            if ($r['masuk'] || $r['keluar']) $c['hadir']++;
            if ($r['hari'] !== 'Minggu' && $r['j'] !== 'Libur') $c['hari_kerja']++;
            if ($r['telat'] > 0) { $c['telat_kali']++; $c['telat_menit'] += $r['telat']; }
            if ($r['cepat'] > 0) { $c['cepat_kali']++; $c['cepat_menit'] += $r['cepat']; }
            $kat = kategoriJ($r['j']);
            if ($kat !== '') $c[$kat]++;
        }
        unset($c);
    }
}

// hari kerja efektif per orang + hadir efektif (dibatasi maksimal hari efektif)
$EF = hariEfektifDetail($start, $end);
$HARI_EF = $EF['total'];
foreach ($perKar as &$kr) {
    $kr['hadir_ef'] = min($kr['hadir'], $HARI_EF);   // tidak boleh melebihi hari efektif
    $perDiv[$kr['div']]['hadir_ef'] += $kr['hadir_ef'];
}
unset($kr);

// total keseluruhan
$total = counterBaru();
foreach ($perDiv as $c) foreach ($c as $k => $v) $total[$k] += $v;

// % Hadir = hadir efektif / (jumlah karyawan x hari kerja efektif)
function persen($c){
    global $HARI_EF;
    $pembagi = $c['karyawan'] * $HARI_EF;
    return $pembagi > 0 ? min(100, round($c['hadir_ef'] / $pembagi * 100, 1)) : 0;
}

// urutkan karyawan: divisi lalu nama
$karList = array_values($perKar);
usort($karList, function($a, $b){
    $c = strcmp($a['div'], $b['div']);
    return $c !== 0 ? $c : strcasecmp($a['nama'], $b['nama']);
});

// total semua karyawan (untuk baris TOTAL di tabel rekap per karyawan)
$totKar = counterBaru();
foreach ($karList as $k) {
    foreach ($totKar as $f => $v) $totKar[$f] += $k[$f] ?? 0;
}
$totKar['karyawan'] = count($karList);

// urutkan harian: tanggal terbaru, divisi, nama
usort($allRows, function($a, $b){
    $c = strcmp($b['tanggal'], $a['tanggal']);
    if ($c !== 0) return $c;
    $c = strcmp($a['div'], $b['div']);
    return $c !== 0 ? $c : strcasecmp($a['nama'], $b['nama']);
});

// ==========================================
// MAN HOURS - FORMAT TEMPLATE BULANAN
// ==========================================
$BULAN_NAMA = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

function tglID($t){
    global $BULAN_NAMA;
    $ts = strtotime($t);
    return date('j', $ts) . ' ' . substr($BULAN_NAMA[(int)date('n', $ts)], 0, 3) . ' ' . date('Y', $ts);
}
function blnPendek($t){
    global $BULAN_NAMA;
    return substr($BULAN_NAMA[(int)date('n', strtotime($t))], 0, 3);
}
// geser tanggal n bulan (tanggal akhir bulan tetap jadi akhir bulan)
function geserBulan($tgl, $n){
    $ts   = strtotime($tgl);
    $isLast = ($tgl === date('Y-m-t', $ts));
    $day  = (int)date('j', $ts);
    $t2   = strtotime(date('Y-m-01', $ts) . " $n month");
    $max  = (int)date('t', $t2);
    return date('Y-m', $t2) . '-' . sprintf('%02d', $isLast ? $max : min($day, $max));
}

$mhStart = $_GET['mh_start'] ?? '';
$mhEnd   = $_GET['mh_end'] ?? '';
if (!validTanggal($mhStart) || !validTanggal($mhEnd)) {
    $mhStart = date('Y-m-01');
    $mhEnd   = date('Y-m-t');
}
if (strtotime($mhStart) > strtotime($mhEnd)) { $tmp = $mhStart; $mhStart = $mhEnd; $mhEnd = $tmp; }
$MH_MAX_HARI = 93; // batas maksimal kolom tanggal
if ((strtotime($mhEnd) - strtotime($mhStart)) / 86400 >= $MH_MAX_HARI) {
    $mhEnd = date('Y-m-d', strtotime($mhStart . ' +' . ($MH_MAX_HARI - 1) . ' days'));
}
$mhDates = [];
for ($t = strtotime($mhStart); $t <= strtotime($mhEnd); $t = strtotime('+1 day', $t)) $mhDates[] = date('Y-m-d', $t);
$mhLabel = tglID($mhStart) . ' – ' . tglID($mhEnd);
$hariIni = date('Y-m-d');

// tombol cepat periode
$mhBulanIni  = ['mh_start' => date('Y-m-01'), 'mh_end' => date('Y-m-t')];
$mhBulanLalu = ['mh_start' => date('Y-m-01', strtotime('first day of last month')), 'mh_end' => date('Y-m-t', strtotime('first day of last month'))];
if ((int)date('j') >= 11) {
    $cutS = date('Y-m-11');
    $cutE = date('Y-m-10', strtotime('first day of next month'));
} else {
    $cutS = date('Y-m-11', strtotime('first day of last month'));
    $cutE = date('Y-m-10');
}
$mhCutIni   = ['mh_start' => $cutS, 'mh_end' => $cutE];
$mhCutLalu  = ['mh_start' => geserBulan($cutS, -1), 'mh_end' => geserBulan($cutE, -1)];
$mhPrev = ['mh_start' => geserBulan($mhStart, -1), 'mh_end' => geserBulan($mhEnd, -1)];
$mhNext = ['mh_start' => geserBulan($mhStart, 1),  'mh_end' => geserBulan($mhEnd, 1)];

$mh = [];
$mhErr = [];
foreach ($targetDivisi as $kode => $cfg) {
    $err = '';
    $rowsMH = ambilDivisi($kode, $cfg, $mhStart, $mhEnd, $q, $err);
    if ($rowsMH === null) { $mhErr[$kode] = $err; continue; }

    foreach ($rowsMH as $r) {
        $kk = $kode . '|' . $r['no_id'];
        if (!isset($mh[$kk])) {
            $mh[$kk] = ['div'=>$kode, 'no_id'=>$r['no_id'], 'nama'=>$r['nama'], 'days'=>[],
                        'cnt'=>array_fill_keys(array_keys($MH_KODE), 0), 'jam'=>0];
        }
        if ($r['tanggal'] > $hariIni) continue;   // tanggal yang belum terjadi dikosongkan
        $code = kodeMH($r);
        $mh[$kk]['days'][$r['tanggal']] = $code;
        $mh[$kk]['cnt'][$code]++;
    }
}
foreach ($mh as $kk => $m) {
    $mh[$kk]['tot'] = totalMH($m['cnt']);
    $hariHitung = $mh[$kk]['tot']['H'] + ($MH_DL_DIHITUNG ? $m['cnt']['DL'] : 0);
    $mh[$kk]['jam'] = $hariHitung * $MH_JAM_PER_HARI;
}
$mhList = array_values($mh);
usort($mhList, function($a, $b){
    $c = strcmp($a['div'], $b['div']);
    return $c !== 0 ? $c : strcasecmp($a['nama'], $b['nama']);
});
$mhTotalJam = 0;
$mhTotalCnt = array_fill_keys($MH_URUT, 0);
foreach ($mhList as $m) {
    $mhTotalJam += $m['jam'];
    foreach ($m['tot'] as $kd => $v) $mhTotalCnt[$kd] += $v;
}

// Export Excel (.xls berwarna, format template)
if (isset($_GET['export']) && $_GET['export'] === 'manhours') {
    header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
    header('Content-Disposition: attachment; filename="man_hours_' . $mhStart . '_sd_' . $mhEnd . '.xls"');
    echo "\xEF\xBB\xBF<html><head><meta charset='utf-8'></head><body>";
    echo "<table border='1' cellspacing='0' cellpadding='3' style='border-collapse:collapse;font-family:Arial;font-size:11px'>";
    echo "<tr style='background:#6b8e23;color:#fff;font-weight:bold'><td colspan='2'>Periode</td><td colspan='" . (count($mhDates) + 1 + count($MH_URUT)) . "' style='background:#fef3c7;color:#000'>" . e($mhLabel) . "</td></tr>";
    echo "<tr style='font-weight:bold;color:#fff'>";
    foreach (['Employee ID','Nama Lengkap','Departemen'] as $h) echo "<td style='background:#2bb5c8'>$h</td>";
    foreach ($mhDates as $d) echo "<td align='center' style='background:#2bb5c8'>" . (int)date('j', strtotime($d)) . '/' . blnPendek($d) . '</td>';
    foreach ($MH_URUT as $kd) echo "<td align='center' bgcolor='{$MH_HEAD[$kd][0]}' style='background:{$MH_HEAD[$kd][0]};color:{$MH_HEAD[$kd][1]}'>" . e(isset($MH_HEAD_LABEL[$kd]) ? 'Total ' . $MH_HEAD_LABEL[$kd] : "Total $kd") . "</td>";
    echo "<td align='center' style='background:{$MH_HEAD_JAM[0]};color:{$MH_HEAD_JAM[1]}'>Total Jam Kerja</td></tr>";
    foreach ($mhList as $m) {
        echo '<tr><td>' . e($m['no_id']) . '</td><td>' . e($m['nama']) . '</td><td>' . e($DIVISI[$m['div']]['nama']) . '</td>';
        foreach ($mhDates as $d) {
            $kd = $m['days'][$d] ?? '';
            $sc = $MH_KODE[$kd] ?? ['#ffffff', '#000000'];
            echo "<td align='center' bgcolor='{$sc[0]}' style='background:{$sc[0]};color:{$sc[1]}'>" . e($kd) . '</td>';
        }
        foreach ($MH_URUT as $kd) echo "<td align='center' bgcolor='{$MH_HEAD[$kd][0]}' style='background:{$MH_HEAD[$kd][0]};color:{$MH_HEAD[$kd][1]}'>" . $m['tot'][$kd] . '</td>';
        echo "<td align='center' bgcolor='{$MH_HEAD_JAM[0]}' style='background:#dcfce7'><b>" . $m['jam'] . '</b></td></tr>';
    }
    echo "<tr style='font-weight:bold;background:#f1f5f9'><td colspan='" . (3 + count($mhDates)) . "' align='right'>TOTAL</td>";
    foreach ($MH_URUT as $kd) echo "<td align='center'>" . $mhTotalCnt[$kd] . '</td>';
    echo "<td align='center'>" . $mhTotalJam . '</td></tr>';
    echo "<tr><td colspan='" . (4 + count($mhDates) + count($MH_URUT)) . "'>Keterangan: ";
    foreach ($MH_KODE as $kd => $sc) echo "<span style='background:{$sc[0]};color:{$sc[1]}'>&nbsp;$kd = " . e($sc[2]) . "&nbsp;</span> ";
    echo '</td></tr></table></body></html>';
    exit;
}

// ==========================================
// KARYAWAN TELADAN (BEST EMPLOYEE)
// ==========================================
$beStart = $_GET['be_start'] ?? '';
$beEnd   = $_GET['be_end'] ?? '';
if (!validTanggal($beStart) || !validTanggal($beEnd)) {
    $beStart = date('Y-m-01');
    $beEnd   = date('Y-m-t');
}
if (strtotime($beStart) > strtotime($beEnd)) { $tmp = $beStart; $beStart = $beEnd; $beEnd = $tmp; }
if ((strtotime($beEnd) - strtotime($beStart)) / 86400 > 366) {
    $beEnd = date('Y-m-d', strtotime($beStart . ' +365 days'));
}
$beLabel = tglID($beStart) . ' – ' . tglID($beEnd);

$beBulanIni  = ['be_start' => $mhBulanIni['mh_start'],  'be_end' => $mhBulanIni['mh_end']];
$beBulanLalu = ['be_start' => $mhBulanLalu['mh_start'], 'be_end' => $mhBulanLalu['mh_end']];
$beCutIni    = ['be_start' => $mhCutIni['mh_start'],    'be_end' => $mhCutIni['mh_end']];
$beCutLalu   = ['be_start' => $mhCutLalu['mh_start'],   'be_end' => $mhCutLalu['mh_end']];

$be = [];
$beErr = [];
foreach ($targetDivisi as $kode => $cfg) {
    $err = '';
    $rowsBE = ambilDivisi($kode, $cfg, $beStart, $beEnd, $q, $err);
    if ($rowsBE === null) { $beErr[$kode] = $err; continue; }

    foreach ($rowsBE as $r) {
        if ($r['tanggal'] > $hariIni) continue;   // tanggal yang belum terjadi
        $kk = $kode . '|' . $r['no_id'];
        if (!isset($be[$kk])) {
            $be[$kk] = ['div'=>$kode, 'no_id'=>$r['no_id'], 'nama'=>$r['nama'],
                        'cnt'=>array_fill_keys(array_keys($MH_KODE), 0),
                        'lupa'=>0, 'telat'=>0, 'telat_mnt'=>0, 'cepat'=>0];
        }
        $code = kodeMH($r);
        if (in_array($code, ['T', 'PC', 'TP'], true)) $code = 'H';   // telat / pulang cepat tetap hadir
        $be[$kk]['cnt'][$code]++;
        if ($code === 'H') {
            if (!empty($r['masuk']) && empty($r['keluar']) && $r['tanggal'] < $hariIni) $be[$kk]['lupa']++;
            if ($r['telat'] > 0) { $be[$kk]['telat']++; $be[$kk]['telat_mnt'] += $r['telat']; }
            if ($r['cepat'] > 0) $be[$kk]['cepat']++;
        }
    }
}

$beList = [];
$beTanpaHadir = 0;
foreach ($be as $b) {
    $b['hadir'] = $b['cnt']['H'] + $b['cnt']['DL'];
    if ($b['hadir'] === 0) { $beTanpaHadir++; continue; }  // tidak pernah hadir di periode ini: tidak diranking
    $b['pengurang'] = $b['cnt']['CT'] * $BE_PENALTI['cuti']
                    + $b['cnt']['S'] * $BE_PENALTI['sakit']
                    + $b['cnt']['I'] * $BE_PENALTI['izin']
                    + $b['cnt']['A'] * $BE_PENALTI['alpha']
                    + $b['lupa']      * $BE_PENALTI['tidak_clockout']
                    + $b['telat']     * $BE_PENALTI['telat']
                    + $b['cepat']     * $BE_PENALTI['pulang_cepat'];
    $b['skor'] = max(0, $BE_SKOR_AWAL - $b['pengurang']);
    $beList[] = $b;
}
// urut: skor tertinggi, lalu hari hadir terbanyak, telat paling sedikit, nama
usort($beList, function($a, $b){
    if ($a['skor'] !== $b['skor']) return $b['skor'] <=> $a['skor'];
    if ($a['hadir'] !== $b['hadir']) return $b['hadir'] <=> $a['hadir'];
    if ($a['telat_mnt'] !== $b['telat_mnt']) return $a['telat_mnt'] <=> $b['telat_mnt'];
    return strcasecmp($a['nama'], $b['nama']);
});

if (isset($_GET['export']) && $_GET['export'] === 'teladan') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="karyawan_teladan_' . $beStart . '_sd_' . $beEnd . '.csv"');
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Peringkat','Divisi','No ID','Nama','Hadir (H)','Dinas Luar','Cuti','Sakit','Izin','Alpa','Tidak Clock Out','Telat (kali)','Pulang Cepat (kali)','Total Pengurang','Skor'], ';');
    foreach ($beList as $i => $b) {
        fputcsv($out, [$i + 1, $DIVISI[$b['div']]['nama'], $b['no_id'], $b['nama'], $b['cnt']['H'], $b['cnt']['DL'], $b['cnt']['CT'],
            $b['cnt']['S'], $b['cnt']['I'], $b['cnt']['A'], $b['lupa'], $b['telat'], $b['cepat'], $b['pengurang'], $b['skor']], ';');
    }
    fclose($out);
    exit;
}

// ==========================================
// EXPORT CSV
// ==========================================
if (isset($_GET['export'])) {
    $mode = $_GET['export'] === 'harian' ? 'harian' : 'karyawan';
    $fname = "rekap_semua_divisi_{$mode}_{$start}_sd_{$end}.csv";

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $fname . '"');
    echo "\xEF\xBB\xBF"; // BOM agar Excel membaca UTF-8
    $out = fopen('php://output', 'w');

    if ($mode === 'harian') {
        fputcsv($out, ['Divisi','No ID','Nama','Tanggal','Hari','Masuk','Keluar','Telat (menit)','Pulang Cepat (menit)','Justifikasi'], ';');
        foreach ($allRows as $r) {
            fputcsv($out, [$DIVISI[$r['div']]['nama'], $r['no_id'], $r['nama'], date('d-m-Y', strtotime($r['tanggal'])),
                $r['hari'], $r['masuk'], $r['keluar'], $r['telat'] ?: '', $r['cepat'] ?: '', $r['j']], ';');
        }
    } else {
        fputcsv($out, ['Divisi','No ID','Nama','Hadir','Hari Kerja Efektif','% Hadir','Status KPI (>= ' . $KPI_HADIR_MIN . '%)','Telat (kali)','Telat (menit)',
            'Pulang Cepat (kali)','Pulang Cepat (menit)','Sakit','Izin','Alpha','Dinas','Cuti','Libur','Lainnya'], ';');
        foreach ($karList as $k) {
            $pk = persen($k);
            fputcsv($out, [$DIVISI[$k['div']]['nama'], $k['no_id'], $k['nama'], $k['hadir'], $HARI_EF, $pk,
                $pk >= $KPI_HADIR_MIN ? 'Tercapai' : 'Belum tercapai',
                $k['telat_kali'], $k['telat_menit'], $k['cepat_kali'], $k['cepat_menit'],
                $k['sakit'], $k['izin'], $k['alpha'], $k['dinas'], $k['cuti'], $k['libur'], $k['lainnya']], ';');
        }
        // baris TOTAL
        fputcsv($out, ['TOTAL', '', '', $totKar['hadir'], $HARI_EF, persen($totKar),
            persen($totKar) >= $KPI_HADIR_MIN ? 'Tercapai' : 'Belum tercapai',
            $totKar['telat_kali'], $totKar['telat_menit'], $totKar['cepat_kali'], $totKar['cepat_menit'],
            $totKar['sakit'], $totKar['izin'], $totKar['alpha'], $totKar['dinas'], $totKar['cuti'], $totKar['libur'], $totKar['lainnya']], ';');
    }
    fclose($out);
    exit;
}

// ==========================================
// HELPER TAMPILAN
// ==========================================
function url($extra = []){
    $p = array_merge($_GET, $extra);
    foreach ($p as $k => $v) if ($v === '' || $v === null) unset($p[$k]);
    return 'rekap_semua.php?' . http_build_query($p);
}
function jClass($j){
    $k = strtolower($j);
    $map = ['sakit'=>'sakit','izin'=>'izin','alpha'=>'alpha','dinas'=>'dinas','libur'=>'libur','cuti'=>'cuti','normal'=>'normal',
            'telat'=>'telat','pulang cepat'=>'telat','telat & pulang cepat'=>'telat'];
    return $map[$k] ?? 'lainnya';
}

$bulanIni  = ['start' => date('Y-m-01'), 'end' => date('Y-m-d')];
$bulanLalu = ['start' => date('Y-m-01', strtotime('first day of last month')), 'end' => date('Y-m-t', strtotime('first day of last month'))];
$tujuhHari = ['start' => date('Y-m-d', strtotime('-6 days')), 'end' => date('Y-m-d')];

// paginasi harian
$PER_PAGE   = 300;
$totalRows  = count($allRows);
$totalPages = max(1, (int)ceil($totalRows / $PER_PAGE));
$page       = min($page, $totalPages);
$pageRows   = array_slice($allRows, ($page - 1) * $PER_PAGE, $PER_PAGE);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Rekap Absensi Seluruh Divisi</title>
<style>
:root{
    --bg:#f1f5f9; --card:#fff; --text:#0f172a; --muted:#64748b; --border:#e2e8f0;
    --blue:#2563eb; --blue2:#1d4ed8; --shadow:0 12px 35px rgba(15,23,42,.10); --radius:16px;
}
*{box-sizing:border-box}
body{margin:0;padding:22px;font-family:system-ui,-apple-system,Segoe UI,Roboto;background:var(--bg);color:var(--text)}
.container{max-width:1500px;margin:auto;display:flex;flex-direction:column;gap:18px}
.card{background:var(--card);padding:20px;border-radius:var(--radius);box-shadow:var(--shadow);border:1px solid rgba(226,232,240,.8)}
.header{display:flex;justify-content:space-between;align-items:flex-start;gap:15px;flex-wrap:wrap}
.header h2{margin:0;font-size:22px}
.header p{margin:4px 0 0;color:var(--muted);font-size:13px}
.btn{padding:10px 16px;border-radius:12px;border:0;background:var(--blue);color:#fff;cursor:pointer;font-size:14px;
text-decoration:none;font-weight:600;display:inline-flex;align-items:center;gap:8px;white-space:nowrap}
.btn:hover{background:var(--blue2)}
.btn.dark{background:#0f172a}
.btn.light{background:#f1f5f9;color:#0f172a;border:1px solid var(--border)}
.btn.light:hover{background:#e2e8f0}
.btn.sm{padding:7px 12px;font-size:13px;border-radius:10px}
.actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center}

.filter{display:grid;grid-template-columns:170px 170px 1fr 220px auto;gap:10px;align-items:end;margin-top:16px}
.filter label{display:block;font-size:12px;color:var(--muted);margin-bottom:5px}
.input{width:100%;padding:10px 12px;border-radius:12px;border:1px solid var(--border);font-size:14px;outline:none;background:#fff}
.input:focus{border-color:#93c5fd;box-shadow:0 0 0 4px rgba(37,99,235,.12)}
.presets{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;align-items:center;font-size:13px;color:var(--muted)}

.alert{padding:12px 14px;border-radius:12px;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;font-size:13px}

.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:14px}
.stat{background:var(--card);border-radius:14px;padding:16px 18px;border:1px solid var(--border);box-shadow:var(--shadow)}
.stat b{display:block;font-size:26px;line-height:1.1}
.stat span{font-size:13px;color:var(--muted)}
.stat.alpha b{color:#dc2626}.stat.telat b{color:#ea580c}.stat.ok b{color:#16a34a}.stat.izin b{color:#0e7490}

.tabs{display:flex;gap:8px;flex-wrap:wrap}
.tab{padding:9px 16px;border-radius:999px;border:1px solid var(--border);background:#fff;color:var(--text);
text-decoration:none;font-size:14px;font-weight:600}
.tab.active{background:var(--blue);border-color:var(--blue);color:#fff}

h3{margin:0 0 12px;font-size:17px}
.table-wrap{overflow:auto;border-radius:14px;border:1px solid var(--border)}
table{width:100%;border-collapse:collapse;font-size:14px}
thead th{background:linear-gradient(180deg,#2563eb,#1d4ed8);color:#fff;padding:12px;text-align:left;font-weight:700;
position:sticky;top:0;white-space:nowrap;z-index:2}
thead th.sortable{cursor:pointer;user-select:none}
thead th.sortable:hover{background:#1e40af}
tbody td{padding:11px 12px;border-bottom:1px solid #eef2f7;vertical-align:middle;white-space:nowrap}
tbody tr:hover{background:#f8fafc}
tfoot td{padding:12px;font-weight:800;background:#f1f5f9;border-top:2px solid var(--border);white-space:nowrap}
#tblKar tfoot td{position:sticky;bottom:0;z-index:2}
.c{text-align:center}
.muted{color:var(--muted)}
.dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:8px}
.divname{font-weight:700;display:inline-flex;align-items:center}

.bar{display:inline-block;width:70px;height:8px;background:#e2e8f0;border-radius:99px;overflow:hidden;vertical-align:middle;margin-right:8px}
.bar i{display:block;height:100%;background:#22c55e;border-radius:99px}

.pill{display:inline-flex;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:700;border:1px solid}
.pill.normal{background:#f1f5f9;border-color:#cbd5e1;color:#0f172a}
.pill.sakit{background:#fef9c3;border-color:#facc15;color:#854d0e}
.pill.izin{background:#a5f3fc;border-color:#06b6d4;color:#155e75}
.pill.alpha{background:#dc2626;border-color:#7f1d1d;color:#fff}
.pill.telat{background:#ffedd5;border-color:#f97316;color:#9a3412}
.pill.dinas{background:#f3e8ff;border-color:#a855f7;color:#6b21a8}
.pill.libur{background:#dcfce7;border-color:#22c55e;color:#166534}
.pill.cuti{background:#dbeafe;border-color:#3b82f6;color:#1e3a8a}
.pill.lainnya{background:#e0e7ff;border-color:#6366f1;color:#3730a3}
.time{font-variant-numeric:tabular-nums;font-size:13px}
.red{color:#dc2626;font-weight:700}
.orange{color:#ea580c;font-weight:700}
.num0{color:#cbd5e1}

.toolbar{display:flex;gap:10px;justify-content:space-between;align-items:center;flex-wrap:wrap;margin-bottom:12px}
.pager{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-top:14px;font-size:13px;color:var(--muted)}
.footer{color:var(--muted);font-size:13px;text-align:center}

/* ===== SHEET TABS & MAN HOURS ===== */
.sheet-tabs{display:flex;gap:8px;flex-wrap:wrap}
.sheet-tab{padding:10px 18px;border-radius:12px;border:1px solid var(--border);background:#fff;cursor:pointer;font-weight:700;font-size:14px;color:var(--text)}
.sheet-tab.active{background:var(--blue);border-color:var(--blue);color:#fff}
.legend{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}
.lg{padding:5px 12px;border-radius:8px;border:1px solid #cbd5e1;font-size:12px;font-weight:700}
.mhbar{display:flex;gap:10px;flex-wrap:wrap;align-items:end;margin-bottom:14px}
.mhbar label{display:block;font-size:12px;color:var(--muted);margin-bottom:5px}
.mhtitle{display:flex;gap:0;margin-bottom:12px;font-weight:700;font-size:13px;border:1px solid #6b8e23;width:max-content;max-width:100%}
.mhtitle span{padding:8px 14px}
.mhtitle .a{background:#6b8e23;color:#fff}
.mhtitle .b{background:#fef3c7;color:#0f172a;min-width:160px;text-align:center}
table.mh{width:auto;min-width:100%;font-size:12px}
.mh td,.mh th{padding:5px 4px;text-align:center;white-space:nowrap}
.mh thead th{background:#2bb5c8;color:#fff;font-size:12px;padding:8px 4px;background-image:none}
.mh thead th.sun{background:#0e7490}
.mh thead th small{display:block;font-weight:400;font-size:10px;opacity:.9}
.podium{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px;margin-bottom:16px}
.pod{border-radius:16px;padding:16px 18px;border:1px solid var(--border);background:#fff;display:flex;gap:14px;align-items:center}
.pod .medal{font-size:38px;line-height:1}
.pod b{display:block;font-size:16px}
.pod span{font-size:12px;color:var(--muted)}
.pod .sk{margin-left:auto;text-align:right;font-size:26px;font-weight:800;color:#16a34a;line-height:1}
.pod .sk small{display:block;font-size:11px;font-weight:600;color:var(--muted)}
.pod.g1{background:linear-gradient(135deg,#fef9c3,#fff);border-color:#facc15}
.pod.g2{background:linear-gradient(135deg,#f1f5f9,#fff);border-color:#cbd5e1}
.pod.g3{background:linear-gradient(135deg,#ffedd5,#fff);border-color:#fdba74}
.be-rule{background:#f0fdf4;border:1px solid #bbf7d0;color:#14532d;border-radius:12px;padding:12px 14px;font-size:13px;line-height:1.6;margin-bottom:14px}
.skor{display:inline-block;min-width:48px;padding:4px 10px;border-radius:999px;font-weight:800;background:#dcfce7;color:#166534;border:1px solid #86efac}
.skor.mid{background:#fef9c3;color:#854d0e;border-color:#facc15}
.skor.low{background:#fee2e2;color:#991b1b;border-color:#fca5a5}
tr.top3 td{background:#fffbeb}
.mhpreset{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:14px;font-size:13px;color:var(--muted)}
.mh td.cd{min-width:32px;font-weight:600;border:1px solid #d9e2ec}
.mh td.nm{text-align:left;padding-left:8px}
.mh .stk{position:sticky;background:#fff;z-index:1;text-align:left;padding-left:8px}
.mh thead .stk{background:#2bb5c8;z-index:3}
.mh tfoot .stk{background:#f1f5f9}
.mh .s1{left:0;min-width:90px;max-width:90px}
.mh .s2{left:90px;min-width:190px;max-width:190px;overflow:hidden;text-overflow:ellipsis}
.mh .s3{left:280px;min-width:110px;max-width:110px;border-right:2px solid var(--border)}
.mh td.tot{font-weight:700;background:#f8fafc;min-width:54px}
.mh thead th.th-tot{min-width:54px}

@media(max-width:1100px){.filter{grid-template-columns:1fr 1fr}}
@media(max-width:600px){body{padding:12px}.filter{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="container">

    <!-- PILIHAN SHEET -->
    <div class="sheet-tabs">
        <button type="button" class="sheet-tab active" data-s="sheetRekap">📊 Rekap Absensi</button>
        <button type="button" class="sheet-tab" data-s="sheetMH">⏱ Man Hours</button>
        <button type="button" class="sheet-tab" data-s="sheetBE">🏆 Karyawan Teladan</button>
    </div>

<!-- ======================= SHEET 1: REKAP ABSENSI ======================= -->
<div id="sheetRekap" style="display:flex;flex-direction:column;gap:18px">

    <!-- HEADER + FILTER -->
    <div class="card">
        <div class="header">
            <div>
                <h2>📊 Rekap Absensi Seluruh Divisi</h2>
                <p>Gabungan data <?= count($DIVISI) ?> divisi • <?= date('d M Y', strtotime($start)) ?> – <?= date('d M Y', strtotime($end)) ?> • Hari kerja efektif: <b><?= $HARI_EF ?></b> hari/orang • Target hadir ≥ <?= $KPI_HADIR_MIN ?>%</p>
            </div>
            <div class="actions">
                <a href="index.php" class="btn light">🏠 Dashboard</a>
            </div>
        </div>

        <form method="get" class="filter">
            <div>
                <label>Dari Tanggal</label>
                <input class="input" type="date" name="start" value="<?= e($start) ?>">
            </div>
            <div>
                <label>Sampai Tanggal</label>
                <input class="input" type="date" name="end" value="<?= e($end) ?>">
            </div>
            <div>
                <label>Cari Nama / No ID</label>
                <input class="input" type="text" name="q" value="<?= e($q) ?>" placeholder="Contoh: Abdul atau 10012">
            </div>
            <div>
                <label>Divisi</label>
                <select class="input" name="divisi">
                    <option value="">Semua Divisi</option>
                    <?php foreach ($DIVISI as $k => $d): ?>
                        <option value="<?= e($k) ?>" <?= $divisiPilih === $k ? 'selected' : '' ?>><?= e($d['nama']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn">🔍 Terapkan</button>
        </form>

        <div class="presets">
            Cepat:
            <a class="btn light sm" href="<?= e(url($bulanIni + ['page'=>''])) ?>">Bulan ini</a>
            <a class="btn light sm" href="<?= e(url($bulanLalu + ['page'=>''])) ?>">Bulan lalu</a>
            <a class="btn light sm" href="<?= e(url($tujuhHari + ['page'=>''])) ?>">7 hari terakhir</a>
            <a class="btn light sm" href="rekap_semua.php">♻ Reset</a>
        </div>
    </div>

    <?php foreach ($errors as $kode => $msg): ?>
        <div class="alert">⚠️ Divisi <b><?= e($DIVISI[$kode]['nama']) ?></b> gagal dibaca: <?= e($msg) ?>. Data divisi ini tidak ikut dihitung.</div>
    <?php endforeach; ?>

    <!-- KARTU RINGKASAN -->
    <?php $kpiOk = persen($total) >= $KPI_HADIR_MIN; ?>
    <div class="stats">
        <div class="stat"><b><?= number_format($total['karyawan']) ?></b><span>Total Karyawan</span></div>
        <div class="stat"><b><?= $HARI_EF ?></b><span>Hari Kerja Efektif (per orang)</span></div>
        <div class="stat ok"><b><?= number_format($total['hadir']) ?></b><span>Total Kehadiran (hari-orang)</span></div>
        <div class="stat <?= $kpiOk ? 'ok' : 'alpha' ?>"><b><?= persen($total) ?>%</b>
            <span>Persentase Hadir • Target ≥ <?= $KPI_HADIR_MIN ?>% <?= $kpiOk ? '✅ Tercapai' : '❌ Belum tercapai' ?></span></div>
        <div class="stat telat"><b><?= number_format($total['telat_kali']) ?></b><span>Telat (kali) • <?= number_format($total['telat_menit']) ?> mnt</span></div>
        <div class="stat telat"><b><?= number_format($total['cepat_kali']) ?></b><span>Pulang Cepat (kali) • <?= number_format($total['cepat_menit']) ?> mnt</span></div>
        <div class="stat alpha"><b><?= number_format($total['alpha']) ?></b><span>Alpha</span></div>
        <div class="stat"><b><?= number_format($total['sakit']) ?></b><span>Sakit</span></div>
        <div class="stat izin"><b><?= number_format($total['izin']) ?></b><span>Izin</span></div>
        <div class="stat"><b><?= number_format($total['dinas'] + $total['cuti']) ?></b><span>Dinas + Cuti</span></div>
    </div>


    <!-- RINCIAN HARI KERJA EFEKTIF -->
    <div class="card" style="padding:14px 20px;font-size:13px;line-height:1.7">
        <b>📅 Hari kerja efektif periode ini: <?= $HARI_EF ?> hari</b>
        <span class="muted">(<?= date('d M Y', strtotime($start)) ?> – <?= date('d M Y', strtotime($end)) ?>)</span><br>
        <?= $EF['kalender'] ?> hari kalender
        = <b><?= $HARI_EF ?></b> hari efektif
        + <?= $EF['minggu'] ?> hari Minggu
        + <?= count($EF['tanpa_absen']) ?> hari tanpa absen (libur)
        <?= $EF['belum'] ? '+ ' . $EF['belum'] . ' hari belum terjadi' : '' ?>
        <?php if ($EF['tanpa_absen']): ?>
            <br><span class="muted">Hari tanpa absen yang tidak dihitung:</span>
            <?php foreach ($EF['tanpa_absen'] as $tg): ?>
                <span class="pill libur" style="margin:2px 2px 0 0"><?= e($HARI_NAMA[(int)date('w', strtotime($tg))] . ', ' . tglID($tg)) ?></span>
            <?php endforeach; ?>
        <?php endif; ?>
        <?php if ($EF['fallback']): ?>
            <br><span class="red">Database tidak dapat dibaca, semua hari non-Minggu dihitung sebagai hari efektif.</span>
        <?php endif; ?>
    </div>

    <!-- REKAP PER DIVISI -->
    <div class="card">
        <h3>Rekap per Divisi</h3>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Divisi</th>
                        <th class="c">Karyawan</th>
                        <th class="c">Hadir</th>
                        <th>% Hadir (KPI ≥ <?= $KPI_HADIR_MIN ?>%)</th>
                        <th class="c">Telat (kali)</th>
                        <th class="c">Telat (mnt)</th>
                        <th class="c">P. Cepat (kali)</th>
                        <th class="c">P. Cepat (mnt)</th>
                        <th class="c">Sakit</th>
                        <th class="c">Izin</th>
                        <th class="c">Alpha</th>
                        <th class="c">Dinas</th>
                        <th class="c">Cuti</th>
                        <th class="c">Libur</th>
                        <th class="c">Lainnya</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($perDiv as $kode => $c): $d = $DIVISI[$kode]; $p = persen($c); ?>
                    <tr>
                        <td><span class="divname"><span class="dot" style="background:<?= e($d['warna']) ?>"></span><?= e($d['ikon']) ?>&nbsp;<?= e($d['nama']) ?></span></td>
                        <?php if (isset($errors[$kode])): ?>
                            <td colspan="14" class="muted">Tidak dapat terhubung ke database</td>
                        <?php else: ?>
                        <td class="c"><b><?= $c['karyawan'] ?></b></td>
                        <td class="c"><?= number_format($c['hadir']) ?></td>
                        <td><span class="bar"><i style="width:<?= $p ?>%;<?= $p < $KPI_HADIR_MIN ? 'background:#ef4444' : '' ?>"></i></span><b><?= $p ?>%</b> <?= $p >= $KPI_HADIR_MIN ? '✅' : '❌' ?></td>
                        <?php foreach (['telat_kali','telat_menit','cepat_kali','cepat_menit','sakit','izin','alpha','dinas','cuti','libur','lainnya'] as $f): ?>
                            <td class="c <?= $c[$f] ? '' : 'num0' ?> <?= ($f === 'alpha' && $c[$f]) ? 'red' : '' ?> <?= (in_array($f, ['telat_kali','telat_menit','cepat_kali','cepat_menit'], true) && $c[$f]) ? 'orange' : '' ?>"><?= number_format($c[$f]) ?></td>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td>TOTAL</td>
                        <td class="c"><?= number_format($total['karyawan']) ?></td>
                        <td class="c"><?= number_format($total['hadir']) ?></td>
                        <td><?= persen($total) ?>% <?= $kpiOk ? '✅' : '❌' ?></td>
                        <td class="c"><?= number_format($total['telat_kali']) ?></td>
                        <td class="c"><?= number_format($total['telat_menit']) ?></td>
                        <td class="c"><?= number_format($total['cepat_kali']) ?></td>
                        <td class="c"><?= number_format($total['cepat_menit']) ?></td>
                        <td class="c"><?= number_format($total['sakit']) ?></td>
                        <td class="c"><?= number_format($total['izin']) ?></td>
                        <td class="c"><?= number_format($total['alpha']) ?></td>
                        <td class="c"><?= number_format($total['dinas']) ?></td>
                        <td class="c"><?= number_format($total['cuti']) ?></td>
                        <td class="c"><?= number_format($total['libur']) ?></td>
                        <td class="c"><?= number_format($total['lainnya']) ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <!-- REKAP PER KARYAWAN -->
    <div class="card">
        <div class="toolbar">
            <h3 style="margin:0">Rekap per Karyawan <span class="muted" style="font-weight:400;font-size:13px">(klik judul kolom untuk mengurutkan)</span></h3>
            <div class="actions">
                <input class="input" id="quick" type="text" placeholder="Saring cepat nama / ID..." style="width:240px">
                <a class="btn dark sm" href="<?= e(url(['export'=>'karyawan'])) ?>">⬇ Export CSV</a>
            </div>
        </div>
        <div class="table-wrap" style="max-height:640px">
            <table id="tblKar" data-hari-ef="<?= $HARI_EF ?>">
                <thead>
                    <tr>
                        <th class="sortable" data-t="s">Divisi</th>
                        <th class="sortable" data-t="s">No ID</th>
                        <th class="sortable" data-t="s">Nama</th>
                        <th class="sortable c" data-t="n">Hadir</th>
                        <th class="sortable c" data-t="n">% Hadir</th>
                        <th class="sortable c" data-t="n">Telat (kali)</th>
                        <th class="sortable c" data-t="n">Telat (mnt)</th>
                        <th class="sortable c" data-t="n">P. Cepat (kali)</th>
                        <th class="sortable c" data-t="n">P. Cepat (mnt)</th>
                        <th class="sortable c" data-t="n">Sakit</th>
                        <th class="sortable c" data-t="n">Izin</th>
                        <th class="sortable c" data-t="n">Alpha</th>
                        <th class="sortable c" data-t="n">Dinas</th>
                        <th class="sortable c" data-t="n">Cuti</th>
                        <th class="sortable c" data-t="n">Libur</th>
                        <th class="sortable c" data-t="n">Lainnya</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($karList): foreach ($karList as $k): $d = $DIVISI[$k['div']]; ?>
                    <tr>
                        <td data-v="<?= e($d['nama']) ?>"><span class="divname"><span class="dot" style="background:<?= e($d['warna']) ?>"></span><?= e($d['nama']) ?></span></td>
                        <td data-v="<?= e($k['no_id']) ?>"><b><?= e($k['no_id']) ?></b></td>
                        <td data-v="<?= e($k['nama']) ?>"><?= e($k['nama']) ?></td>
                        <td class="c" data-v="<?= $k['hadir'] ?>" data-hef="<?= $k['hadir_ef'] ?>"><?= $k['hadir'] ?></td>
                        <td class="c <?= persen($k) < $KPI_HADIR_MIN ? 'red' : '' ?>" data-v="<?= persen($k) ?>"><?= persen($k) ?>%</td>
                        <?php foreach (['telat_kali','telat_menit','cepat_kali','cepat_menit','sakit','izin','alpha','dinas','cuti','libur','lainnya'] as $f): ?>
                            <td class="c <?= $k[$f] ? '' : 'num0' ?> <?= ($f === 'alpha' && $k[$f]) ? 'red' : '' ?> <?= (in_array($f, ['telat_kali','telat_menit','cepat_kali','cepat_menit'], true) && $k[$f]) ? 'orange' : '' ?>" data-v="<?= $k[$f] ?>"><?= $k[$f] ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="16" class="c muted" style="padding:20px">Data tidak ditemukan</td></tr>
                <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3">TOTAL</td>
                        <td class="c" data-col="3"><?= number_format($totKar['hadir']) ?></td>
                        <td class="c" id="totPersen"><?= persen($totKar) ?>%</td>
                        <?php $ci = 5; foreach (['telat_kali','telat_menit','cepat_kali','cepat_menit','sakit','izin','alpha','dinas','cuti','libur','lainnya'] as $f): ?>
                            <td class="c" data-col="<?= $ci++ ?>"><?= number_format($totKar[$f]) ?></td>
                        <?php endforeach; ?>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="pager"><span>Total karyawan: <b id="countKar"><?= count($karList) ?></b> • % Hadir merah = di bawah target KPI <?= $KPI_HADIR_MIN ?>%</span></div>
    </div>

    <!-- DETAIL HARIAN -->
    <div class="card" id="harian">
        <div class="toolbar">
            <h3 style="margin:0">Detail Harian Semua Divisi</h3>
            <a class="btn dark sm" href="<?= e(url(['export'=>'harian'])) ?>">⬇ Export CSV (semua data)</a>
        </div>
        <div class="table-wrap" style="max-height:680px">
            <table>
                <thead>
                    <tr>
                        <th class="c">No</th>
                        <th>Divisi</th>
                        <th>No ID</th>
                        <th>Nama</th>
                        <th>Tanggal</th>
                        <th>Hari</th>
                        <th>Masuk</th>
                        <th>Keluar</th>
                        <th class="c">Telat (mnt)</th>
                        <th class="c">P. Cepat (mnt)</th>
                        <th>Justifikasi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($pageRows): $no = ($page - 1) * $PER_PAGE + 1; foreach ($pageRows as $r): $d = $DIVISI[$r['div']]; ?>
                    <tr>
                        <td class="c muted"><?= $no++ ?></td>
                        <td><span class="divname"><span class="dot" style="background:<?= e($d['warna']) ?>"></span><?= e($d['nama']) ?></span></td>
                        <td><b><?= e($r['no_id']) ?></b></td>
                        <td><?= e($r['nama']) ?></td>
                        <td><?= date('d-m-Y', strtotime($r['tanggal'])) ?></td>
                        <td><?= $r['hari'] === 'Minggu' ? '<span class="red">Minggu</span>' : e($r['hari']) ?></td>
                        <td class="time <?= $r['telat'] ? 'orange' : '' ?>"><?= $r['masuk'] ? e($r['masuk']) : '<span class="muted">-</span>' ?></td>
                        <td class="time <?= $r['cepat'] ? 'orange' : '' ?>"><?= $r['keluar'] ? e($r['keluar']) : '<span class="muted">-</span>' ?></td>
                        <td class="c"><?= $r['telat'] ? '<span class="orange">' . $r['telat'] . '</span>' : '<span class="muted">-</span>' ?></td>
                        <td class="c"><?= $r['cepat'] ? '<span class="orange">' . $r['cepat'] . '</span>' : '<span class="muted">-</span>' ?></td>
                        <td><span class="pill <?= jClass($r['j']) ?>"><?= e($r['j']) ?></span></td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="11" class="c muted" style="padding:20px">Data tidak ditemukan</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="pager">
            <span>Total data: <b><?= number_format($totalRows) ?></b> • Halaman <?= $page ?> / <?= $totalPages ?></span>
            <?php if ($page > 1): ?><a class="btn light sm" href="<?= e(url(['page'=>$page-1])) . '#harian' ?>">← Sebelumnya</a><?php endif; ?>
            <?php if ($page < $totalPages): ?><a class="btn light sm" href="<?= e(url(['page'=>$page+1])) . '#harian' ?>">Berikutnya →</a><?php endif; ?>
        </div>
    </div>

</div><!-- /sheetRekap -->

<!-- ======================= SHEET 2: MAN HOURS ======================= -->
<div id="sheetMH" style="display:none;flex-direction:column;gap:18px">

    <?php foreach ($mhErr as $kode => $msg): ?>
        <div class="alert">⚠️ Divisi <b><?= e($DIVISI[$kode]['nama']) ?></b> gagal dibaca: <?= e($msg) ?>. Data divisi ini tidak ikut dihitung.</div>
    <?php endforeach; ?>

    <div class="card">
        <div class="toolbar">
            <h3 style="margin:0">⏱ Man Hours Karyawan</h3>
            <div class="actions">
                <a class="btn light sm" href="<?= e(url($mhPrev)) ?>#manhours">← Periode sebelumnya</a>
                <a class="btn light sm" href="<?= e(url($mhNext)) ?>#manhours">Periode berikutnya →</a>
                <a class="btn dark sm" href="<?= e(url(['export'=>'manhours'])) ?>">⬇ Export Excel</a>
            </div>
        </div>

        <form method="get" action="rekap_semua.php#manhours" class="mhbar">
            <input type="hidden" name="start" value="<?= e($start) ?>">
            <input type="hidden" name="end" value="<?= e($end) ?>">
            <div><label>Dari Tanggal</label><input class="input" type="date" name="mh_start" value="<?= e($mhStart) ?>" style="width:165px"></div>
            <div><label>Sampai Tanggal</label><input class="input" type="date" name="mh_end" value="<?= e($mhEnd) ?>" style="width:165px"></div>
            <div><label>Divisi</label>
                <select class="input" name="divisi" style="width:180px">
                    <option value="">Semua Divisi</option>
                    <?php foreach ($DIVISI as $k => $d): ?>
                        <option value="<?= e($k) ?>" <?= $divisiPilih === $k ? 'selected' : '' ?>><?= e($d['nama']) ?></option>
                    <?php endforeach; ?>
                </select></div>
            <div><label>Cari Nama / No ID</label><input class="input" type="text" name="q" value="<?= e($q) ?>" style="width:200px" placeholder="Nama / ID"></div>
            <button type="submit" class="btn">🔍 Terapkan</button>
            <div><label>&nbsp;</label><input class="input" id="quickMH" type="text" placeholder="Saring cepat..." style="width:170px"></div>
        </form>

        <div class="mhpreset">
            Cepat:
            <a class="btn light sm" href="<?= e(url($mhBulanIni)) ?>#manhours">Bulan ini</a>
            <a class="btn light sm" href="<?= e(url($mhBulanLalu)) ?>#manhours">Bulan lalu</a>
            <a class="btn light sm" href="<?= e(url($mhCutIni)) ?>#manhours">Cut-off 11–10 (<?= e(tglID($cutS)) ?> – <?= e(tglID($cutE)) ?>)</a>
            <a class="btn light sm" href="<?= e(url($mhCutLalu)) ?>#manhours">Cut-off 11–10 sebelumnya</a>
        </div>

        <div class="mhtitle"><span class="a">Periode</span><span class="b"><?= e($mhLabel) ?></span></div>

        <div class="legend">
            <?php foreach ($MH_KODE as $kd => $sc): ?>
                <span class="lg" style="background:<?= $sc[0] ?>;color:<?= $sc[1] ?>"><?= e($kd) ?> = <?= e($sc[2]) ?></span>
            <?php endforeach; ?>
        </div>

        <div class="table-wrap" style="max-height:700px">
            <table class="mh" id="tblMH">
                <thead>
                    <tr>
                        <th class="stk s1">Employee ID</th>
                        <th class="stk s2">Nama Lengkap</th>
                        <th class="stk s3">Departemen</th>
                        <?php foreach ($mhDates as $d): $w = (int)date('w', strtotime($d)); ?>
                            <th class="<?= $w === 0 ? 'sun' : '' ?>" title="<?= e($HARI_NAMA[$w] . ', ' . tglID($d)) ?>"><?= (int)date('j', strtotime($d)) ?><small><?= e(blnPendek($d)) ?></small></th>
                        <?php endforeach; ?>
                        <?php foreach ($MH_URUT as $kd): ?>
                            <th class="th-tot" style="background:<?= $MH_HEAD[$kd][0] ?>;color:<?= $MH_HEAD[$kd][1] ?>">Total <?= e($MH_HEAD_LABEL[$kd] ?? $kd) ?></th>
                        <?php endforeach; ?>
                        <th class="th-tot" style="background:<?= $MH_HEAD_JAM[0] ?>;color:<?= $MH_HEAD_JAM[1] ?>">Total Jam Kerja</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($mhList): foreach ($mhList as $m): $dv = $DIVISI[$m['div']]; ?>
                    <tr>
                        <td class="stk s1"><b><?= e($m['no_id']) ?></b></td>
                        <td class="stk s2"><?= e($m['nama']) ?></td>
                        <td class="stk s3"><?= e($dv['nama']) ?></td>
                        <?php foreach ($mhDates as $d):
                            $kd = $m['days'][$d] ?? '';
                            $sc = $MH_KODE[$kd] ?? ['#ffffff', '#0f172a', '']; ?>
                            <td class="cd" style="background:<?= $sc[0] ?>;color:<?= $sc[1] ?>" title="<?= e(tglID($d) . ($sc[2] ? ' • ' . $sc[2] : '')) ?>"><?= e($kd) ?></td>
                        <?php endforeach; ?>
                        <?php foreach ($MH_URUT as $kd): ?>
                            <td class="tot <?= $m['tot'][$kd] ? '' : 'num0' ?>" style="<?= $m['tot'][$kd] ? 'background:' . $MH_HEAD[$kd][0] . ';color:' . $MH_HEAD[$kd][1] : '' ?>"><?= $m['tot'][$kd] ?></td>
                        <?php endforeach; ?>
                        <td class="tot" style="background:#dcfce7"><?= number_format($m['jam']) ?></td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="<?= count($mhDates) + 4 + count($MH_URUT) ?>" class="muted" style="padding:20px">Data tidak ditemukan</td></tr>
                <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="<?= 3 + count($mhDates) ?>" style="text-align:right">TOTAL</td>
                        <?php foreach ($MH_URUT as $kd): ?><td><?= number_format($mhTotalCnt[$kd]) ?></td><?php endforeach; ?>
                        <td><?= number_format($mhTotalJam) ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div class="pager">
            <span>Total karyawan: <b id="countMH"><?= count($mhList) ?></b> • Total jam kerja: <b><?= number_format($mhTotalJam) ?> jam</b></span>
        </div>
        <div class="pager" style="margin-top:4px">
            Total Jam Kerja = jumlah hari hadir (H + T + PC + TP)<?= $MH_DL_DIHITUNG ? ' + DL' : '' ?> × <?= $MH_JAM_PER_HARI ?> jam. T / PC / TP = hadir tetapi telat / pulang cepat. Tanggal yang belum terjadi dikosongkan. Periode (maks. <?= $MH_MAX_HARI ?> hari) dipilih bebas lewat Dari/Sampai Tanggal, mis. cut-off 11 s/d 10.
        </div>
    </div>

</div><!-- /sheetMH -->

<!-- ======================= SHEET 3: KARYAWAN TELADAN ======================= -->
<div id="sheetBE" style="display:none;flex-direction:column;gap:18px">

    <?php foreach ($beErr as $kode => $msg): ?>
        <div class="alert">⚠️ Divisi <b><?= e($DIVISI[$kode]['nama']) ?></b> gagal dibaca: <?= e($msg) ?>. Data divisi ini tidak ikut dihitung.</div>
    <?php endforeach; ?>

    <div class="card">
        <div class="toolbar">
            <h3 style="margin:0">🏆 Karyawan Teladan <span class="muted" style="font-weight:400;font-size:13px">(Best Employee • <?= e($beLabel) ?>)</span></h3>
            <div class="actions">
                <a class="btn dark sm" href="<?= e(url(['export'=>'teladan'])) ?>">⬇ Export CSV</a>
            </div>
        </div>

        <form method="get" action="rekap_semua.php#teladan" class="mhbar">
            <input type="hidden" name="start" value="<?= e($start) ?>">
            <input type="hidden" name="end" value="<?= e($end) ?>">
            <input type="hidden" name="mh_start" value="<?= e($mhStart) ?>">
            <input type="hidden" name="mh_end" value="<?= e($mhEnd) ?>">
            <div><label>Dari Tanggal</label><input class="input" type="date" name="be_start" value="<?= e($beStart) ?>" style="width:165px"></div>
            <div><label>Sampai Tanggal</label><input class="input" type="date" name="be_end" value="<?= e($beEnd) ?>" style="width:165px"></div>
            <div><label>Divisi</label>
                <select class="input" name="divisi" style="width:180px">
                    <option value="">Semua Divisi</option>
                    <?php foreach ($DIVISI as $k => $d): ?>
                        <option value="<?= e($k) ?>" <?= $divisiPilih === $k ? 'selected' : '' ?>><?= e($d['nama']) ?></option>
                    <?php endforeach; ?>
                </select></div>
            <div><label>Cari Nama / No ID</label><input class="input" type="text" name="q" value="<?= e($q) ?>" style="width:200px" placeholder="Nama / ID"></div>
            <button type="submit" class="btn">🔍 Terapkan</button>
            <div><label>&nbsp;</label><input class="input" id="quickBE" type="text" placeholder="Saring cepat..." style="width:170px"></div>
        </form>

        <div class="mhpreset">
            Cepat:
            <a class="btn light sm" href="<?= e(url($beBulanIni)) ?>#teladan">Bulan ini</a>
            <a class="btn light sm" href="<?= e(url($beBulanLalu)) ?>#teladan">Bulan lalu</a>
            <a class="btn light sm" href="<?= e(url($beCutIni)) ?>#teladan">Cut-off 11–10 (<?= e(tglID($cutS)) ?> – <?= e(tglID($cutE)) ?>)</a>
            <a class="btn light sm" href="<?= e(url($beCutLalu)) ?>#teladan">Cut-off 11–10 sebelumnya</a>
        </div>

        <div class="be-rule">
            <b>Cara penilaian:</b> setiap karyawan mulai dari skor <b><?= $BE_SKOR_AWAL ?></b>, lalu dikurangi:
            <b>Alpa</b> −<?= $BE_PENALTI['alpha'] ?>/hari •
            <b>Cuti</b> −<?= $BE_PENALTI['cuti'] ?>/hari •
            <b>Sakit</b> −<?= $BE_PENALTI['sakit'] ?>/hari •
            <b>Izin</b> −<?= $BE_PENALTI['izin'] ?>/hari •
            <b>Pulang cepat</b> −<?= $BE_PENALTI['pulang_cepat'] ?>/kali •
            <b>Terlambat</b> −<?= $BE_PENALTI['telat'] ?>/kali.
            <?php if ($BE_PENALTI['tidak_clockout'] > 0): ?> Tidak Clock Out −<?= $BE_PENALTI['tidak_clockout'] ?>/hari.<?php endif; ?>
            <b>Dinas Luar tidak mengurangi skor.</b>
            Semakin tinggi skor, semakin rajin. Bila skor sama, urutan ditentukan oleh hari hadir terbanyak, lalu menit terlambat paling sedikit.
            Karyawan yang tidak pernah hadir di periode ini tidak diranking<?= $beTanpaHadir ? ' (' . $beTanpaHadir . ' orang)' : '' ?>.
            Hari ini dan tanggal yang belum terjadi tidak dihitung Alpa.
        </div>

        <?php if ($beList): ?>
        <div class="podium">
            <?php foreach (array_slice($beList, 0, 3) as $i => $b): $dv = $DIVISI[$b['div']]; ?>
                <div class="pod g<?= $i + 1 ?>">
                    <div class="medal"><?= ['🥇','🥈','🥉'][$i] ?></div>
                    <div><b><?= e($b['nama']) ?></b><span><span class="dot" style="background:<?= e($dv['warna']) ?>;width:8px;height:8px"></span><?= e($dv['nama']) ?> • ID <?= e($b['no_id']) ?></span></div>
                    <div class="sk"><?= $b['skor'] ?><small>skor</small></div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="table-wrap" style="max-height:680px">
            <table id="tblBE">
                <thead>
                    <tr>
                        <th class="c">Peringkat</th>
                        <th>No ID</th>
                        <th>Nama</th>
                        <th>Divisi</th>
                        <th class="c">Hadir (H)</th>
                        <th class="c">Dinas Luar</th>
                        <th class="c">Cuti</th>
                        <th class="c">Sakit</th>
                        <th class="c">Izin</th>
                        <th class="c">Alpa</th>
                        <th class="c">Tdk Clock Out</th>
                        <th class="c">Telat (kali)</th>
                        <th class="c">P. Cepat (kali)</th>
                        <th class="c">Pengurang</th>
                        <th class="c">Skor</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($beList): foreach ($beList as $i => $b): $dv = $DIVISI[$b['div']];
                    $kls = $b['skor'] >= $BE_SKOR_AWAL - 5 ? '' : ($b['skor'] >= $BE_SKOR_AWAL - 15 ? 'mid' : 'low'); ?>
                    <tr class="<?= $i < 3 ? 'top3' : '' ?>">
                        <td class="c"><b><?= $i < 3 ? ['🥇','🥈','🥉'][$i] : $i + 1 ?></b></td>
                        <td><b><?= e($b['no_id']) ?></b></td>
                        <td><?= e($b['nama']) ?><?= $b['pengurang'] === 0 ? ' <span title="Tanpa pengurang">⭐</span>' : '' ?></td>
                        <td><span class="divname"><span class="dot" style="background:<?= e($dv['warna']) ?>"></span><?= e($dv['nama']) ?></span></td>
                        <?php foreach ([$b['cnt']['H'], $b['cnt']['DL'], $b['cnt']['CT'], $b['cnt']['S'], $b['cnt']['I'], $b['cnt']['A'], $b['lupa'], $b['telat'], $b['cepat'], $b['pengurang']] as $n): ?>
                            <td class="c <?= $n ? '' : 'num0' ?>"><?= $n ?></td>
                        <?php endforeach; ?>
                        <td class="c"><span class="skor <?= $kls ?>"><?= $b['skor'] ?></span></td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="15" class="c muted" style="padding:20px">Data tidak ditemukan</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager"><span>Total karyawan diranking: <b id="countBE"><?= count($beList) ?></b> • ⭐ = tanpa pengurang sama sekali</span></div>
    </div>

</div><!-- /sheetBE -->

    <div class="footer">
        Aturan hitung sama dengan rekap tiap divisi: tanpa data absen = Alpha (Minggu = Libur); telat/pulang cepat dihitung dari jam kerja.
        % Hadir = Hadir ÷ (Jumlah karyawan × <?= $HARI_EF ?> hari kerja efektif, yaitu hari non-Minggu yang ada absen; hari tanpa absen sama sekali tidak dihitung); target KPI ≥ <?= $KPI_HADIR_MIN ?>%.
    </div>
</div>

<script>
(function(){
    // ===== pindah sheet =====
    const stabs = document.querySelectorAll('.sheet-tab');
    function showSheet(id){
        ['sheetRekap','sheetMH','sheetBE'].forEach(s => {
            document.getElementById(s).style.display = (s === id ? 'flex' : 'none');
        });
        stabs.forEach(t => t.classList.toggle('active', t.dataset.s === id));
        const hs = {sheetMH:'#manhours', sheetBE:'#teladan'}[id];
        history.replaceState(null, '', hs ? hs : (location.pathname + location.search));
    }
    stabs.forEach(t => t.addEventListener('click', () => showSheet(t.dataset.s)));
    if (location.hash === '#manhours') showSheet('sheetMH');
    if (location.hash === '#teladan') showSheet('sheetBE');

    // ===== saring cepat (rekap karyawan) + total dinamis =====
    const quick = document.getElementById('quick');
    const tbl   = document.getElementById('tblKar');
    const count = document.getElementById('countKar');

    function hitungTotalKar(){
        if (!tbl) return;
        const hariEf = parseFloat(tbl.dataset.hariEf) || 0;
        const sums = {};
        let n = 0, hef = 0;
        tbl.querySelectorAll('tbody tr').forEach(tr => {
            if (tr.style.display === 'none' || tr.children.length < 16) return;
            n++;
            hef += parseFloat(tr.children[3].dataset.hef) || 0;
            for (let i = 3; i <= 15; i++) {
                if (i === 4) continue;
                sums[i] = (sums[i] || 0) + (parseFloat(tr.children[i].dataset.v) || 0);
            }
        });
        tbl.querySelectorAll('tfoot td[data-col]').forEach(td => {
            td.textContent = (sums[td.dataset.col] || 0).toLocaleString('en-US');
        });
        const pembagi = n * hariEf;
        const p = pembagi > 0 ? Math.min(100, Math.round(hef / pembagi * 1000) / 10) : 0;
        const el = document.getElementById('totPersen');
        if (el) el.textContent = p + '%';
        if (count) count.textContent = n;
    }

    if (quick && tbl) {
        quick.addEventListener('input', function(){
            const v = quick.value.trim().toLowerCase();
            tbl.querySelectorAll('tbody tr').forEach(tr => {
                tr.style.display = (!v || tr.textContent.toLowerCase().includes(v)) ? '' : 'none';
            });
            hitungTotalKar();
        });
    }

    // ===== saring cepat (man hours) =====
    const quickMH = document.getElementById('quickMH');
    const tblMH   = document.getElementById('tblMH');
    const countMH = document.getElementById('countMH');

    if (quickMH && tblMH) {
        quickMH.addEventListener('input', function(){
            const v = quickMH.value.trim().toLowerCase();
            let n = 0;
            tblMH.querySelectorAll('tbody tr').forEach(tr => {
                const key = Array.from(tr.querySelectorAll('.stk')).map(td => td.textContent).join(' ').toLowerCase();
                const show = !v || key.includes(v);
                tr.style.display = show ? '' : 'none';
                if (show) n++;
            });
            if (countMH) countMH.textContent = n;
        });
    }

    // ===== saring cepat (teladan) =====
    const quickBE = document.getElementById('quickBE');
    const tblBE   = document.getElementById('tblBE');
    const countBE = document.getElementById('countBE');
    if (quickBE && tblBE) {
        quickBE.addEventListener('input', function(){
            const v = quickBE.value.trim().toLowerCase();
            let n = 0;
            tblBE.querySelectorAll('tbody tr').forEach(tr => {
                const show = !v || tr.textContent.toLowerCase().includes(v);
                tr.style.display = show ? '' : 'none';
                if (show) n++;
            });
            if (countBE) countBE.textContent = n;
        });
    }

    // ===== urut kolom =====
    if (tbl) {
        const ths = tbl.querySelectorAll('thead th.sortable');
        ths.forEach((th, idx) => {
            let asc = true;
            th.addEventListener('click', function(){
                const tbody = tbl.querySelector('tbody');
                const rows  = Array.from(tbody.querySelectorAll('tr'));
                const num   = th.dataset.t === 'n';
                rows.sort((a, b) => {
                    const x = a.children[idx].dataset.v ?? a.children[idx].textContent;
                    const y = b.children[idx].dataset.v ?? b.children[idx].textContent;
                    const r = num ? (parseFloat(x) - parseFloat(y)) : x.localeCompare(y, 'id', {numeric:true, sensitivity:'base'});
                    return asc ? r : -r;
                });
                rows.forEach(r => tbody.appendChild(r));
                ths.forEach(t => t.textContent = t.textContent.replace(/ [▲▼]$/, ''));
                th.textContent += asc ? ' ▲' : ' ▼';
                asc = !asc;
            });
        });
    }
})();
</script>
</body>
</html>