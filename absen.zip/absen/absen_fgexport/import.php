<?php

use PhpOffice\PhpSpreadsheet\Cell\Cell;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Reader\Csv;
use PhpOffice\PhpSpreadsheet\Reader\Html;
use PhpOffice\PhpSpreadsheet\Reader\Xls;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Xml;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

require_once __DIR__ . '/vendor/autoload.php';
include __DIR__ . '/config.php';

/**
 * Hentikan proses import dengan pesan yang aman ditampilkan.
 */
function gagalImport(string $pesan): void
{
    http_response_code(400);
    echo '<!doctype html><html lang="id"><head><meta charset="utf-8">';
    echo '<title>Import gagal</title></head><body>';
    echo '<h2>Import gagal</h2>';
    echo '<p>' . htmlspecialchars($pesan, ENT_QUOTES, 'UTF-8') . '</p>';
    echo '<p><a href="index.php">Kembali ke halaman Workshop</a></p>';
    echo '</body></html>';
    exit;
}

/**
 * Informasi teknis singkat untuk mengenali format internal file mesin.
 * Hanya membaca signature/header biner, bukan isi data karyawan.
 */
function diagnostikFormat(string $file): string
{
    $ukuran = filesize($file);
    $ukuran = $ukuran === false ? 0 : $ukuran;

    $mime = 'tidak diketahui';
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo !== false) {
            $hasilMime = finfo_file($finfo, $file);
            finfo_close($finfo);
            if (is_string($hasilMime) && $hasilMime !== '') {
                $mime = $hasilMime;
            }
        }
    }

    $handle = fopen($file, 'rb');
    $header = $handle !== false ? fread($handle, 16) : false;
    if ($handle !== false) {
        fclose($handle);
    }

    $header = is_string($header) ? $header : '';
    $hexRapat = strtoupper(bin2hex($header));
    $hex = trim(implode(' ', str_split($hexRapat, 2)));

    $jenis = 'signature tidak dikenal';
    if (str_starts_with($hexRapat, 'D0CF11E0A1B11AE1')) {
        $jenis = 'OLE/BIFF standar XLS';
    } elseif (str_starts_with($hexRapat, '504B0304')) {
        $jenis = 'ZIP/OpenXML XLSX';
    } elseif (
        str_starts_with($hexRapat, '0908') ||
        str_starts_with($hexRapat, '0904') ||
        str_starts_with($hexRapat, '0902') ||
        str_starts_with($hexRapat, '0900')
    ) {
        $jenis = 'raw BIFF lama tanpa container OLE';
    } elseif (str_starts_with($hexRapat, 'FFFE')) {
        $jenis = 'teks UTF-16LE';
    } elseif (str_starts_with($hexRapat, 'FEFF')) {
        $jenis = 'teks UTF-16BE';
    } else {
        $awalTeks = strtolower(ltrim($header));
        if (str_starts_with($awalTeks, '<html') || str_starts_with($awalTeks, '<!doctype')) {
            $jenis = 'HTML dengan ekstensi XLS';
        } elseif (str_starts_with($awalTeks, '<?xml')) {
            $jenis = 'XML dengan ekstensi XLS';
        }
    }

    return sprintf(
        'Jenis: %s; MIME: %s; ukuran: %d byte; signature: %s',
        $jenis,
        $mime,
        $ukuran,
        $hex !== '' ? $hex : '(kosong)'
    );
}

/**
 * Ubah file teks UTF-16/UTF-8 menjadi UTF-8 agar file HTML, XML,
 * atau teks bertab yang memakai ekstensi .xls tetap dapat dibaca.
 */
function teksKeUtf8(string $isi): string
{
    if (str_starts_with($isi, "\xEF\xBB\xBF")) {
        return substr($isi, 3);
    }

    if (str_starts_with($isi, "\xFF\xFE")) {
        return mb_convert_encoding(substr($isi, 2), 'UTF-8', 'UTF-16LE');
    }

    if (str_starts_with($isi, "\xFE\xFF")) {
        return mb_convert_encoding(substr($isi, 2), 'UTF-8', 'UTF-16BE');
    }

    // Sebagian mesin menulis UTF-16 tanpa BOM.
    $contoh = substr($isi, 0, 4096);
    $jumlahNull = substr_count($contoh, "\0");

    if ($jumlahNull > 10) {
        $encoding = mb_detect_encoding(
            $isi,
            ['UTF-16LE', 'UTF-16BE'],
            true
        );

        if ($encoding !== false) {
            return mb_convert_encoding($isi, 'UTF-8', $encoding);
        }
    }

    if (!mb_check_encoding($isi, 'UTF-8')) {
        $encoding = mb_detect_encoding(
            $isi,
            ['Windows-1252', 'ISO-8859-1'],
            true
        );

        if ($encoding !== false) {
            return mb_convert_encoding($isi, 'UTF-8', $encoding);
        }
    }

    return $isi;
}

/**
 * Tentukan delimiter untuk file teks/CSV dari mesin absensi.
 */
function cariDelimiter(string $isi): string
{
    $barisPertama = strtok($isi, "\r\n");

    if ($barisPertama === false) {
        return "\t";
    }

    $jumlah = [
        "\t" => substr_count($barisPertama, "\t"),
        ';'  => substr_count($barisPertama, ';'),
        ','  => substr_count($barisPertama, ','),
    ];

    arsort($jumlah);
    $delimiter = array_key_first($jumlah);

    return $jumlah[$delimiter] > 0 ? $delimiter : "\t";
}

/**
 * Membaca raw BIFF lama tanpa container OLE.
 *
 * Mesin absensi pada contoh 1.xls menghasilkan stream worksheet BIFF lama
 * secara langsung. Microsoft Excel masih dapat membukanya, tetapi reader XLS
 * standar mengharapkan container OLE. Data mesin disimpan sebagai record
 * LABEL 0x0004 dengan struktur row, column, 3-byte attribute, length, text.
 */
function bacaRawBiffLama(string $isi): Spreadsheet
{
    $ukuran = strlen($isi);

    if ($ukuran < 10) {
        throw new RuntimeException('Raw BIFF terlalu pendek.');
    }

    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('Data Mesin');

    $posisi = 0;
    $jumlahSel = 0;
    $menemukanBof = false;
    $menemukanEof = false;

    while ($posisi + 4 <= $ukuran) {
        $header = unpack(
            'vrecord/vpanjang',
            substr($isi, $posisi, 4)
        );

        if (!is_array($header)) {
            throw new RuntimeException('Header record raw BIFF tidak valid.');
        }

        $record = (int) $header['record'];
        $panjang = (int) $header['panjang'];
        $awalData = $posisi + 4;
        $akhirData = $awalData + $panjang;

        if ($akhirData > $ukuran) {
            throw new RuntimeException('Panjang record raw BIFF tidak valid.');
        }

        $data = substr($isi, $awalData, $panjang);

        // BOF: 0x0809, 0x0409, 0x0209, atau 0x0009.
        if (in_array($record, [0x0809, 0x0409, 0x0209, 0x0009], true)) {
            $menemukanBof = true;
        }

        // LABEL BIFF lama (teks).
        if ($record === 0x0004 && $panjang >= 8) {
            $infoBaris = unpack('vnilai', substr($data, 0, 2));
            $infoKolom = unpack('vnilai', substr($data, 2, 2));

            if (!is_array($infoBaris) || !is_array($infoKolom)) {
                throw new RuntimeException('Posisi sel raw BIFF tidak valid.');
            }

            $baris = (int) $infoBaris['nilai'];
            $kolom = (int) $infoKolom['nilai'];
            $panjangTeks = ord($data[7]);

            if (8 + $panjangTeks <= $panjang) {
                $teks = substr($data, 8, $panjangTeks);
                $teks = rtrim($teks, "\0");

                if (!mb_check_encoding($teks, 'UTF-8')) {
                    $teks = mb_convert_encoding(
                        $teks,
                        'UTF-8',
                        'Windows-1252'
                    );
                }

                // Batas format XLS lama.
                if ($baris < 65536 && $kolom < 256) {
                    $koordinat = Coordinate::stringFromColumnIndex($kolom + 1)
                        . ($baris + 1);

                    $sheet->setCellValueExplicit(
                        $koordinat,
                        $teks,
                        DataType::TYPE_STRING
                    );

                    $jumlahSel++;
                }
            }
        }

        // EOF.
        if ($record === 0x000A) {
            $menemukanEof = true;
            break;
        }

        $posisi = $akhirData;
    }

    if (!$menemukanBof || !$menemukanEof || $jumlahSel === 0) {
        $spreadsheet->disconnectWorksheets();

        throw new RuntimeException(
            'Struktur raw BIFF tidak lengkap atau tidak mengandung data.'
        );
    }

    return $spreadsheet;
}

/**
 * Baca file upload. Mendukung:
 * - XLS asli (Excel 97-2003/BIFF)
 * - raw BIFF lama dari mesin absensi tanpa container OLE
 * - XLSX
 * - HTML yang diberi ekstensi .xls
 * - Spreadsheet XML yang diberi ekstensi .xls
 * - Teks tab/CSV yang diberi ekstensi .xls
 */
function bacaSpreadsheet(
    string $file,
    string $ekstensi,
    array &$fileSementara
): Spreadsheet {
    $percobaan = [];

    // Prioritaskan reader sesuai ekstensi asli.
    if ($ekstensi === 'xls') {
        $percobaan = [new Xls(), new Xlsx()];
    } else {
        $percobaan = [new Xlsx(), new Xls()];
    }

    foreach ($percobaan as $reader) {
        try {
            return $reader->load($file);
        } catch (Throwable $e) {
            // Lanjut ke reader/fallback berikutnya.
        }
    }

    $isi = file_get_contents($file);

    if ($isi === false || $isi === '') {
        throw new RuntimeException('File kosong atau tidak dapat dibaca.');
    }

    // Raw BIFF lama seperti file 1.xls dari mesin Workshop.
    $signatureRawBiff = ["\x09\x08", "\x09\x04", "\x09\x02", "\x09\x00"];
    foreach ($signatureRawBiff as $signature) {
        if (str_starts_with($isi, $signature)) {
            return bacaRawBiffLama($isi);
        }
    }

    $isiUtf8 = teksKeUtf8($isi);
    $awal = ltrim($isiUtf8);

    $fileTeks = tempnam(sys_get_temp_dir(), 'absen_workshop_');

    if ($fileTeks === false) {
        throw new RuntimeException('Tidak dapat membuat file sementara.');
    }

    $fileSementara[] = $fileTeks;

    if (file_put_contents($fileTeks, $isiUtf8) === false) {
        throw new RuntimeException('Tidak dapat memproses file sementara.');
    }

    // Banyak mesin absensi menghasilkan tabel HTML dengan ekstensi .xls.
    if (
        stripos($awal, '<html') !== false ||
        stripos($awal, '<table') !== false ||
        stripos($awal, '<!doctype') !== false
    ) {
        $reader = new Html();
        $reader->setSuppressLoadWarnings(true);

        return $reader->load($fileTeks);
    }

    // Excel 2003 Spreadsheet XML yang memakai ekstensi .xls.
    if (
        str_starts_with($awal, '<?xml') ||
        stripos($awal, 'urn:schemas-microsoft-com:office:spreadsheet') !== false
    ) {
        try {
            $reader = new Xml();

            return $reader->load($fileTeks);
        } catch (Throwable $e) {
            // Jika bukan Spreadsheet XML yang valid, coba sebagai teks.
        }
    }

    // Fallback untuk data bertab, titik koma, atau CSV dari mesin.
    if (strpos(substr($isiUtf8, 0, 8192), "\0") === false) {
        $reader = new Csv();
        $reader->setInputEncoding('UTF-8');
        $reader->setDelimiter(cariDelimiter($isiUtf8));
        $reader->setEnclosure('"');
        $reader->setEscapeCharacter('');

        return $reader->load($fileTeks);
    }

    throw new RuntimeException(
        'Format internal file tidak dikenali. File mungkin rusak atau memakai format khusus mesin.'
    );
}

/**
 * Ambil tampilan teks sel dan rapikan spasi.
 */
function nilaiTeks(Cell $cell): string
{
    $nilai = $cell->getFormattedValue();

    if ($nilai === null) {
        return '';
    }

    $nilai = preg_replace('/\s+/u', ' ', (string) $nilai);

    return trim($nilai ?? '');
}

/**
 * Ubah nilai waktu dari XLS/XLSX menjadi format database Y-m-d H:i:s.
 */
function normalisasiWaktu(Cell $cell): ?string
{
    $nilaiAsli = $cell->getValue();

    // Tanggal/waktu Excel asli berbentuk angka serial.
    if (
        is_numeric($nilaiAsli) &&
        ExcelDate::isDateTime($cell)
    ) {
        try {
            return ExcelDate::excelToDateTimeObject((float) $nilaiAsli)
                ->format('Y-m-d H:i:s');
        } catch (Throwable $e) {
            return null;
        }
    }

    $nilai = nilaiTeks($cell);

    if ($nilai === '') {
        return null;
    }

    // Jika format sel hilang tetapi nilainya masih berupa serial Excel.
    if (is_numeric($nilaiAsli)) {
        $serial = (float) $nilaiAsli;

        if ($serial > 1 && $serial < 100000) {
            try {
                return ExcelDate::excelToDateTimeObject($serial)
                    ->format('Y-m-d H:i:s');
            } catch (Throwable $e) {
                // Lanjut mencoba sebagai teks.
            }
        }
    }

    $nilai = str_replace(["\xC2\xA0", 'T'], [' ', ' '], $nilai);
    $nilai = preg_replace('/\s+/u', ' ', $nilai);
    $nilai = trim($nilai ?? '');

    $formatTanggal = [
        'd/m/Y H:i:s',
        'd/m/Y H:i',
        'd-m-Y H:i:s',
        'd-m-Y H:i',
        'Y-m-d H:i:s',
        'Y-m-d H:i',
        'Y/m/d H:i:s',
        'Y/m/d H:i',
        'm/d/Y H:i:s',
        'm/d/Y H:i',
        'm/d/Y g:i:s A',
        'm/d/Y g:i A',
        'd/m/Y g:i:s A',
        'd/m/Y g:i A',
    ];

    foreach ($formatTanggal as $format) {
        $tanggal = DateTime::createFromFormat('!' . $format, $nilai);
        $error = DateTime::getLastErrors();

        $valid = $tanggal !== false && (
            $error === false ||
            ($error['warning_count'] === 0 && $error['error_count'] === 0)
        );

        if ($valid) {
            return $tanggal->format('Y-m-d H:i:s');
        }
    }

    return null;
}

// ===============================
// VALIDASI UPLOAD
// ===============================
if (!isset($_FILES['file'])) {
    gagalImport('File tidak ditemukan.');
}

$upload = $_FILES['file'];

if (!is_array($upload) || !isset($upload['error'], $upload['tmp_name'], $upload['name'])) {
    gagalImport('Data upload tidak valid.');
}

if ((int) $upload['error'] !== UPLOAD_ERR_OK) {
    $pesanUpload = [
        UPLOAD_ERR_INI_SIZE   => 'Ukuran file melebihi batas server.',
        UPLOAD_ERR_FORM_SIZE  => 'Ukuran file terlalu besar.',
        UPLOAD_ERR_PARTIAL    => 'File hanya terunggah sebagian.',
        UPLOAD_ERR_NO_FILE    => 'Belum ada file yang dipilih.',
        UPLOAD_ERR_NO_TMP_DIR => 'Folder sementara server tidak tersedia.',
        UPLOAD_ERR_CANT_WRITE => 'Server gagal menyimpan file upload.',
        UPLOAD_ERR_EXTENSION  => 'Upload dihentikan oleh ekstensi PHP.',
    ];

    gagalImport($pesanUpload[(int) $upload['error']] ?? 'Upload file gagal.');
}

$namaFile = basename((string) $upload['name']);
$ekstensi = strtolower(pathinfo($namaFile, PATHINFO_EXTENSION));

if (!in_array($ekstensi, ['xls', 'xlsx'], true)) {
    gagalImport('Format harus Microsoft Excel .xls atau .xlsx.');
}

$file = (string) $upload['tmp_name'];

if (!is_uploaded_file($file) || !is_readable($file)) {
    gagalImport('File upload tidak tersedia atau tidak dapat dibaca.');
}

// Batas keamanan 25 MB.
$ukuranFile = isset($upload['size']) ? (int) $upload['size'] : filesize($file);

if ($ukuranFile <= 0) {
    gagalImport('File yang diupload kosong.');
}

if ($ukuranFile > 25 * 1024 * 1024) {
    gagalImport('Ukuran file maksimal 25 MB.');
}

// ===============================
// BACA FILE EXCEL
// ===============================
$fileSementara = [];

try {
    $spreadsheet = bacaSpreadsheet($file, $ekstensi, $fileSementara);
} catch (Throwable $e) {
    $diagnostik = diagnostikFormat($file);

    foreach ($fileSementara as $hapusFile) {
        if (is_file($hapusFile)) {
            @unlink($hapusFile);
        }
    }

    gagalImport(
        'File Excel tidak dapat dibaca: ' . $e->getMessage() .
        ' | Diagnostik: ' . $diagnostik
    );
}

$sheet = $spreadsheet->getActiveSheet();
$barisTerakhir = $sheet->getHighestDataRow();

// ===============================
// SIMPAN KE DATABASE
// ===============================
$stmt = $conn->prepare(
    'INSERT INTO absensi (no_id, nama, waktu, status) VALUES (?, ?, ?, ?)'
);

if ($stmt === false) {
    gagalImport('Gagal menyiapkan penyimpanan database: ' . $conn->error);
}

$jumlahBerhasil = 0;
$jumlahDilewati = 0;
$jumlahGagal = 0;

for ($nomorBaris = 1; $nomorBaris <= $barisTerakhir; $nomorBaris++) {
    $noId = nilaiTeks($sheet->getCell('A' . $nomorBaris));
    $nama = nilaiTeks($sheet->getCell('B' . $nomorBaris));
    $status = nilaiTeks($sheet->getCell('D' . $nomorBaris));
    $waktu = normalisasiWaktu($sheet->getCell('C' . $nomorBaris));

    // Header dan baris kosong otomatis dilewati.
    if ($noId === '' || $nama === '' || $status === '' || $waktu === null) {
        $jumlahDilewati++;
        continue;
    }

    $stmt->bind_param('ssss', $noId, $nama, $waktu, $status);

    if ($stmt->execute()) {
        $jumlahBerhasil++;
    } else {
        $jumlahGagal++;
    }
}

$stmt->close();
$spreadsheet->disconnectWorksheets();
unset($spreadsheet);

foreach ($fileSementara as $hapusFile) {
    if (is_file($hapusFile)) {
        @unlink($hapusFile);
    }
}

// Kembali ke halaman Workshop dengan ringkasan hasil import.
$query = http_build_query([
    'import'   => 'success',
    'berhasil' => $jumlahBerhasil,
    'dilewati' => $jumlahDilewati,
    'gagal'    => $jumlahGagal,
]);

header('Location: index.php?' . $query);
exit;
