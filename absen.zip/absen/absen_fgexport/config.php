<?php
// ==========================================
// FIX SESSION PATH (karena default path cPanel error)
// ==========================================
$sessionPath = '/home/potensib/php_sessions';
if(!is_dir($sessionPath)){
    @mkdir($sessionPath, 0755, true);
}
session_save_path($sessionPath);

// ==========================================
// KONEKSI DATABASE
// ==========================================
$conn = new mysqli("localhost", "potensib_pbs", "arsari-group", "potensib_absen_fge");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>