<?php
include 'config.php';

$search = $_GET['search'] ?? '';
$start  = $_GET['start'] ?? '';
$end    = $_GET['end'] ?? '';

$where = "WHERE 1";

if ($search) {
    $s = $conn->real_escape_string($search);
    $where .= " AND (no_id LIKE '%$s%' OR nama LIKE '%$s%')";
}

if ($start && $end) {
    $where .= " AND DATE(waktu) BETWEEN '$start' AND '$end'";
}

$query = "
SELECT 
    no_id,
    nama,
    DATE(waktu) AS tanggal,
    MIN(CASE WHEN status='C/Masuk' THEN TIME(waktu) END) AS masuk,
    MAX(CASE WHEN status='C/Keluar' THEN TIME(waktu) END) AS keluar
FROM absensi
$where
GROUP BY no_id, nama, DATE(waktu)
ORDER BY tanggal DESC
";

$data = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Rekap Absensi</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>

<div class="card">
    <h2>📥 Import Absensi Excel</h2>

    <?php if (($_GET['import'] ?? '') === 'success'): ?>
        <div style="margin-bottom:15px;padding:12px;border:1px solid #86efac;background:#f0fdf4;color:#166534;border-radius:8px;">
            Import selesai —
            berhasil: <strong><?= (int) ($_GET['berhasil'] ?? 0) ?></strong>,
            dilewati: <strong><?= (int) ($_GET['dilewati'] ?? 0) ?></strong>,
            gagal: <strong><?= (int) ($_GET['gagal'] ?? 0) ?></strong>.
        </div>
    <?php endif; ?>

    <form action="import.php" method="POST" enctype="multipart/form-data">
        <input
            type="file"
            name="file"
            accept=".xls,.xlsx,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            required
        >
        <button type="submit">Upload</button>
    </form>

    <small style="display:block;margin-top:10px;color:#64748b;">
        Mendukung file mentah mesin dalam format Excel 97–2003 (.xls) dan Excel Workbook (.xlsx).
    </small>
</div>

<div class="card">
<form method="GET" class="filter">
    <input type="date" name="start" value="<?= $start ?>">
    <input type="date" name="end" value="<?= $end ?>">
    <input type="text" name="search" placeholder="Cari Nama / No ID" value="<?= $search ?>">
    <button>Filter</button>
</form>

<table>
<thead>
<tr>
    <th>No ID</th>
    <th>Nama</th>
    <th>Tanggal</th>
    <th>Masuk</th>
    <th>Keluar</th>
</tr>
</thead>
<tbody>
<?php if ($data && $data->num_rows > 0): ?>
<?php while ($r = $data->fetch_assoc()): ?>
<tr>
    <td><?= $r['no_id'] ?></td>
    <td><?= $r['nama'] ?></td>
    <td><?= $r['tanggal'] ?></td>
    <td><?= $r['masuk'] ?? '-' ?></td>
    <td><?= $r['keluar'] ?? '-' ?></td>
</tr>
<?php endwhile; ?>
<?php else: ?>
<tr>
    <td colspan="5">Data tidak ditemukan</td>
</tr>
<?php endif; ?>
</tbody>
</table>
</div>

</body>
</html>
