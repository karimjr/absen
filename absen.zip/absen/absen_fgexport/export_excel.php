<?php

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;

/*
|--------------------------------------------------------------------------
| OUTPUT BUFFER
|--------------------------------------------------------------------------
| Mencegah file XLSX rusak akibat spasi, warning, atau output lain
| sebelum file Excel dikirim ke browser.
*/
ob_start();

require_once __DIR__ . '/vendor/autoload.php';
include __DIR__ . '/config.php';

// ===============================
// PARAMETER FILTER
// ===============================
$search = $_GET['search'] ?? '';
$no_id  = $_GET['no_id'] ?? '';
$start  = $_GET['start'] ?? '';
$end    = $_GET['end'] ?? '';

// Sort mengikuti admin_rekap.php
$sort_nama    = $_GET['sort_nama'] ?? '';
$sort_tanggal = $_GET['sort_tanggal'] ?? 'desc';

/*
|--------------------------------------------------------------------------
| LIST KARYAWAN MANUAL
|--------------------------------------------------------------------------
| Tambahkan semua karyawan di sini jika tidak menggunakan tabel karyawan.
*/
$karyawanManual = [
    // Contoh:
    // ['no_id' => '1001', 'nama' => 'Budi Santoso'],
    // ['no_id' => '1002', 'nama' => 'Andi Wijaya'],
];

// ===============================
// VALIDASI TANGGAL
// ===============================
if (!$start || !$end) {
    $end   = date('Y-m-d');
    $start = date('Y-m-d', strtotime('-7 days'));
}

$startTs = strtotime($start);
$endTs   = strtotime($end);

if ($startTs === false || $endTs === false) {
    die('Tanggal tidak valid');
}

// Jika tanggal awal lebih besar, tukar posisinya
if ($startTs > $endTs) {
    $tmp   = $start;
    $start = $end;
    $end   = $tmp;

    $startTs = strtotime($start);
    $endTs   = strtotime($end);
}

// Normalisasi tanggal agar aman digunakan di query
$start = date('Y-m-d', $startTs);
$end   = date('Y-m-d', $endTs);

// ===============================
// AMBIL DATA ABSENSI
// ===============================
$where = 'WHERE 1';

if ($search !== '') {
    $s = $conn->real_escape_string($search);
    $where .= " AND nama LIKE '%$s%'";
}

if ($no_id !== '') {
    $id = $conn->real_escape_string($no_id);
    $where .= " AND no_id='$id'";
}

$where .= " AND DATE(waktu) BETWEEN '$start' AND '$end'";

/*
|--------------------------------------------------------------------------
| CATATAN JUSTIFIKASI
|--------------------------------------------------------------------------
| MAX(NULLIF(justifikasi,'')) digunakan untuk mengambil justifikasi
| yang tidak kosong dari record masuk atau keluar.
*/
$sql = "
    SELECT
        no_id,
        nama,
        DATE(waktu) AS tanggal,

        CASE DAYOFWEEK(DATE(waktu))
            WHEN 1 THEN 'Minggu'
            WHEN 2 THEN 'Senin'
            WHEN 3 THEN 'Selasa'
            WHEN 4 THEN 'Rabu'
            WHEN 5 THEN 'Kamis'
            WHEN 6 THEN 'Jumat'
            WHEN 7 THEN 'Sabtu'
        END AS hari_kode,

        MIN(
            CASE
                WHEN status = 'C/Masuk' THEN TIME(waktu)
            END
        ) AS masuk,

        MAX(
            CASE
                WHEN status = 'C/Keluar' THEN TIME(waktu)
            END
        ) AS keluar,

        COALESCE(
            MAX(NULLIF(justifikasi, '')),
            'Normal'
        ) AS justifikasi

    FROM absensi
    $where
    GROUP BY no_id, nama, DATE(waktu)
";

$data = $conn->query($sql);

if ($data === false) {
    die('Gagal mengambil data absensi: ' . $conn->error);
}

// ===============================
// INDEX DATA ABSENSI
// Key: no_id|tanggal
// ===============================
$absenMap = [];
$karyawanDariAbsensi = [];

if ($data->num_rows > 0) {
    while ($r = $data->fetch_assoc()) {
        $key = $r['no_id'] . '|' . $r['tanggal'];

        $absenMap[$key] = $r;

        // Daftar karyawan yang ditemukan dari data absensi
        $karyawanDariAbsensi[$r['no_id']] = $r['nama'];
    }
}

// ===============================
// GABUNG LIST KARYAWAN
// - Dari data absensi
// - Dari list manual
// ===============================
$karyawanGabungan = [];

// Karyawan dari data absensi
foreach ($karyawanDariAbsensi as $id => $nama) {
    $karyawanGabungan[$id] = $nama;
}

// Karyawan dari list manual
foreach ($karyawanManual as $karyawan) {
    if (
        !isset($karyawan['no_id']) ||
        !isset($karyawan['nama'])
    ) {
        continue;
    }

    $karyawanGabungan[$karyawan['no_id']] = $karyawan['nama'];
}

// ===============================
// FILTER KARYAWAN DI PHP
// ===============================
if ($search !== '') {
    $hasilFilter = [];

    foreach ($karyawanGabungan as $id => $nama) {
        if (stripos($nama, $search) !== false) {
            $hasilFilter[$id] = $nama;
        }
    }

    $karyawanGabungan = $hasilFilter;
}

if ($no_id !== '') {
    $hasilFilter = [];

    foreach ($karyawanGabungan as $id => $nama) {
        if ((string) $id === (string) $no_id) {
            $hasilFilter[$id] = $nama;
        }
    }

    $karyawanGabungan = $hasilFilter;
}

// ===============================
// BUAT LIST TANGGAL
// ===============================
$tanggalList = [];

for (
    $tanggalTs = $startTs;
    $tanggalTs <= $endTs;
    $tanggalTs = strtotime('+1 day', $tanggalTs)
) {
    $tanggalList[] = date('Y-m-d', $tanggalTs);
}

// ===============================
// BUAT DATA FINAL
// Semua karyawan x semua tanggal
// ===============================
$finalRows = [];

foreach ($karyawanGabungan as $id => $nama) {
    foreach ($tanggalList as $tanggal) {
        $key = $id . '|' . $tanggal;

        // Jika ada data absensi asli
        if (isset($absenMap[$key])) {
            $finalRows[] = $absenMap[$key];
            continue;
        }

        // Jika tidak ada absensi, buat baris otomatis
        $nomorHari = (int) date('w', strtotime($tanggal));

        // 0 = Minggu, 1 = Senin, dan seterusnya
        $daftarHari = [
            0 => 'Minggu',
            1 => 'Senin',
            2 => 'Selasa',
            3 => 'Rabu',
            4 => 'Kamis',
            5 => 'Jumat',
            6 => 'Sabtu',
        ];

        $namaHari = $daftarHari[$nomorHari];

        // Hari Minggu dianggap Libur, hari lainnya Alpha
        $justifikasiDummy = $namaHari === 'Minggu'
            ? 'Libur'
            : 'Alpha';

        $finalRows[] = [
            'no_id'       => $id,
            'nama'        => $nama,
            'tanggal'     => $tanggal,
            'hari_kode'   => $namaHari,
            'masuk'       => '',
            'keluar'      => '',
            'justifikasi' => $justifikasiDummy,
        ];
    }
}

// ===============================
// SORT DATA FINAL
// ===============================
usort(
    $finalRows,
    function ($a, $b) use ($sort_nama, $sort_tanggal) {
        // Sort nama lebih dahulu jika dipilih
        if ($sort_nama !== '') {
            $perbandinganNama = strcasecmp(
                $a['nama'],
                $b['nama']
            );

            if ($perbandinganNama !== 0) {
                return $sort_nama === 'asc'
                    ? $perbandinganNama
                    : -$perbandinganNama;
            }
        }

        // Sort berdasarkan tanggal
        $perbandinganTanggal = strcmp(
            $a['tanggal'],
            $b['tanggal']
        );

        if ($perbandinganTanggal !== 0) {
            return $sort_tanggal === 'asc'
                ? $perbandinganTanggal
                : -$perbandinganTanggal;
        }

        return 0;
    }
);

// ===============================
// JAM KERJA
// ===============================
function jamKerja($hari)
{
    if ($hari === 'Jumat') {
        return [
            'masuk'  => '08:00:00',
            'keluar' => '17:00:00',
        ];
    }

    if ($hari === 'Sabtu') {
        return [
            'masuk'  => '08:00:00',
            'keluar' => '13:00:00',
        ];
    }

    if ($hari === 'Minggu') {
        // Hari libur, tidak ada jam kerja
        return null;
    }

    // Senin sampai Kamis
    return [
        'masuk'  => '08:00:00',
        'keluar' => '16:00:00',
    ];
}

// ===============================
// HITUNG TELAT DAN PULANG CEPAT
// ===============================
function hitungTelatCepat($hari, $masuk, $keluar)
{
    $hasil = [
        'telat_menit' => null,
        'cepat_menit' => null,
        'telat_flag'  => false,
        'cepat_flag'  => false,
    ];

    $jam = jamKerja($hari);

    // Hari Minggu/libur tidak dihitung
    if ($jam === null) {
        return $hasil;
    }

    // Hitung keterlambatan
    if (!empty($masuk)) {
        $selisihMasuk = (
            strtotime($masuk) -
            strtotime($jam['masuk'])
        ) / 60;

        if ($selisihMasuk > 0) {
            $hasil['telat_menit'] = (int) round($selisihMasuk);
            $hasil['telat_flag']  = true;
        }
    }

    // Hitung pulang cepat
    if (!empty($keluar)) {
        $selisihKeluar = (
            strtotime($jam['keluar']) -
            strtotime($keluar)
        ) / 60;

        if ($selisihKeluar > 0) {
            $hasil['cepat_menit'] = (int) round($selisihKeluar);
            $hasil['cepat_flag']  = true;
        }
    }

    return $hasil;
}

// ========================================================
// BUAT WORKBOOK XLSX
// ========================================================
$spreadsheet = new Spreadsheet();

$spreadsheet->getProperties()
    ->setCreator('Sistem Absensi')
    ->setLastModifiedBy('Sistem Absensi')
    ->setTitle('Rekap Absensi Produksi')
    ->setSubject('Rekap Absensi Produksi')
    ->setDescription('Data rekap absensi divisi produksi');

$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Rekap Absensi');

// ===============================
// HEADER TABEL
// ===============================
$headerKolom = [
    'No',
    'No ID',
    'Nama',
    'Tanggal',
    'Hari',
    'Masuk',
    'Keluar',
    'Telat (menit)',
    'Pulang Cepat (menit)',
    'Justifikasi',
];

$sheet->fromArray($headerKolom, null, 'A1');

$sheet->getStyle('A1:J1')->applyFromArray([
    'font' => [
        'bold' => true,
        'color' => [
            'argb' => 'FFFFFFFF',
        ],
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => [
            'argb' => 'FF2563EB',
        ],
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_CENTER,
        'vertical'   => Alignment::VERTICAL_CENTER,
    ],
]);

$sheet->getRowDimension(1)->setRowHeight(25);
$sheet->freezePane('A2');
$sheet->setAutoFilter('A1:J1');

// Style untuk keterlambatan/pulang cepat
$stylePeringatan = [
    'font' => [
        'bold' => true,
        'color' => [
            'argb' => 'FF9A3412',
        ],
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => [
            'argb' => 'FFFFEDD5',
        ],
    ],
];

// ===============================
// ISI DATA EXCEL
// ===============================
$excelRow = 2;
$nomor = 1;

if (count($finalRows) > 0) {
    foreach ($finalRows as $r) {
        $justifikasi = trim($r['justifikasi'] ?? '');

        if ($justifikasi === '') {
            $justifikasi = 'Normal';
        }

        $hasilPerhitungan = hitungTelatCepat(
            $r['hari_kode'] ?? '',
            $r['masuk'] ?? '',
            $r['keluar'] ?? ''
        );

        /*
        |--------------------------------------------------------------------------
        | JUSTIFIKASI OTOMATIS
        |--------------------------------------------------------------------------
        | Hanya mengubah justifikasi jika status awal masih Normal.
        */
        if (
            $justifikasi === 'Normal' &&
            (
                $hasilPerhitungan['telat_flag'] ||
                $hasilPerhitungan['cepat_flag']
            )
        ) {
            if (
                $hasilPerhitungan['telat_flag'] &&
                $hasilPerhitungan['cepat_flag']
            ) {
                $justifikasi = 'Telat & Pulang Cepat';
            } elseif ($hasilPerhitungan['telat_flag']) {
                $justifikasi = 'Telat';
            } else {
                $justifikasi = 'Pulang Cepat';
            }
        }

        $jamMasuk = !empty($r['masuk'])
            ? $r['masuk']
            : '-';

        $jamKeluar = !empty($r['keluar'])
            ? $r['keluar']
            : '-';

        // Kolom A: Nomor
        $sheet->setCellValue(
            'A' . $excelRow,
            $nomor++
        );

        /*
        |--------------------------------------------------------------------------
        | Kolom B: No ID
        |--------------------------------------------------------------------------
        | Disimpan sebagai teks agar angka nol di depan tidak hilang.
        */
        $sheet->setCellValueExplicit(
            'B' . $excelRow,
            (string) ($r['no_id'] ?? ''),
            DataType::TYPE_STRING
        );

        // Kolom C: Nama
        $sheet->setCellValueExplicit(
            'C' . $excelRow,
            (string) ($r['nama'] ?? ''),
            DataType::TYPE_STRING
        );

        /*
        |--------------------------------------------------------------------------
        | Kolom D: Tanggal
        |--------------------------------------------------------------------------
        | Disimpan sebagai tanggal Excel asli, bukan teks.
        */
        $sheet->setCellValue(
            'D' . $excelRow,
            ExcelDate::PHPToExcel(
                new \DateTime($r['tanggal'])
            )
        );

        $sheet->getStyle('D' . $excelRow)
            ->getNumberFormat()
            ->setFormatCode('dd-mm-yyyy');

        // Kolom E: Hari
        $sheet->setCellValueExplicit(
            'E' . $excelRow,
            (string) ($r['hari_kode'] ?? ''),
            DataType::TYPE_STRING
        );

        // Kolom F: Jam masuk
        $sheet->setCellValueExplicit(
            'F' . $excelRow,
            (string) $jamMasuk,
            DataType::TYPE_STRING
        );

        // Kolom G: Jam keluar
        $sheet->setCellValueExplicit(
            'G' . $excelRow,
            (string) $jamKeluar,
            DataType::TYPE_STRING
        );

        // Kolom H: Telat
        if ($hasilPerhitungan['telat_flag']) {
            $sheet->setCellValue(
                'H' . $excelRow,
                $hasilPerhitungan['telat_menit']
            );
        } else {
            $sheet->setCellValueExplicit(
                'H' . $excelRow,
                '-',
                DataType::TYPE_STRING
            );
        }

        // Kolom I: Pulang cepat
        if ($hasilPerhitungan['cepat_flag']) {
            $sheet->setCellValue(
                'I' . $excelRow,
                $hasilPerhitungan['cepat_menit']
            );
        } else {
            $sheet->setCellValueExplicit(
                'I' . $excelRow,
                '-',
                DataType::TYPE_STRING
            );
        }

        // Kolom J: Justifikasi
        $sheet->setCellValueExplicit(
            'J' . $excelRow,
            (string) $justifikasi,
            DataType::TYPE_STRING
        );

        // ===============================
        // STYLE HARI MINGGU
        // ===============================
        if (($r['hari_kode'] ?? '') === 'Minggu') {
            $sheet->getStyle('E' . $excelRow)
                ->getFont()
                ->setBold(true)
                ->getColor()
                ->setARGB('FFDC2626');
        }

        // ===============================
        // STYLE TERLAMBAT
        // ===============================
        if ($hasilPerhitungan['telat_flag']) {
            $sheet->getStyle('F' . $excelRow)
                ->applyFromArray($stylePeringatan);

            $sheet->getStyle('H' . $excelRow)
                ->applyFromArray($stylePeringatan);
        }

        // ===============================
        // STYLE PULANG CEPAT
        // ===============================
        if ($hasilPerhitungan['cepat_flag']) {
            $sheet->getStyle('G' . $excelRow)
                ->applyFromArray($stylePeringatan);

            $sheet->getStyle('I' . $excelRow)
                ->applyFromArray($stylePeringatan);
        }

        // ===============================
        // STYLE JUSTIFIKASI
        // ===============================
        $justifikasiLower = strtolower($justifikasi);

        if ($justifikasiLower === 'alpha') {
            $sheet->getStyle('J' . $excelRow)
                ->getFont()
                ->setBold(true)
                ->getColor()
                ->setARGB('FFFFFFFF');

            $sheet->getStyle('J' . $excelRow)
                ->getFill()
                ->setFillType(Fill::FILL_SOLID)
                ->getStartColor()
                ->setARGB('FFDC2626');
        } elseif ($justifikasiLower === 'izin') {
            $sheet->getStyle('J' . $excelRow)
                ->getFont()
                ->setBold(true)
                ->getColor()
                ->setARGB('FF0E7490');
        } elseif ($justifikasiLower === 'libur') {
            $sheet->getStyle('J' . $excelRow)
                ->getFont()
                ->setBold(true)
                ->getColor()
                ->setARGB('FFDC2626');
        } elseif ($justifikasiLower === 'cuti') {
            $sheet->getStyle('J' . $excelRow)
                ->getFont()
                ->setBold(true)
                ->getColor()
                ->setARGB('FF0F766E');
        } elseif (
            in_array(
                $justifikasi,
                [
                    'Telat',
                    'Pulang Cepat',
                    'Telat & Pulang Cepat',
                ],
                true
            )
        ) {
            $sheet->getStyle('J' . $excelRow)
                ->applyFromArray($stylePeringatan);
        }

        $excelRow++;
    }

    $lastRow = $excelRow - 1;
} else {
    // Jika tidak ada data
    $sheet->mergeCells('A2:J2');

    $sheet->setCellValue(
        'A2',
        'Data tidak ditemukan'
    );

    $sheet->getStyle('A2')
        ->getAlignment()
        ->setHorizontal(Alignment::HORIZONTAL_CENTER);

    $lastRow = 2;
}

// ===============================
// BORDER SELURUH TABEL
// ===============================
$sheet->getStyle('A1:J' . $lastRow)->applyFromArray([
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => [
                'argb' => 'FFB7B7B7',
            ],
        ],
    ],
]);

// ===============================
// ALIGNMENT
// ===============================
$sheet->getStyle('A1:J' . $lastRow)
    ->getAlignment()
    ->setVertical(Alignment::VERTICAL_CENTER);

if (count($finalRows) > 0) {
    $sheet->getStyle('A2:B' . $lastRow)
        ->getAlignment()
        ->setHorizontal(Alignment::HORIZONTAL_CENTER);

    $sheet->getStyle('D2:I' . $lastRow)
        ->getAlignment()
        ->setHorizontal(Alignment::HORIZONTAL_CENTER);
}

$sheet->getStyle('J1:J' . $lastRow)
    ->getAlignment()
    ->setWrapText(true);

// ===============================
// UKURAN KOLOM
// ===============================
$ukuranKolom = [
    'A' => 8,
    'B' => 16,
    'C' => 30,
    'D' => 15,
    'E' => 14,
    'F' => 13,
    'G' => 13,
    'H' => 18,
    'I' => 24,
    'J' => 28,
];

foreach ($ukuranKolom as $kolom => $ukuran) {
    $sheet->getColumnDimension($kolom)
        ->setWidth($ukuran);
}

// ===============================
// KIRIM FILE XLSX KE BROWSER
// ===============================

// Bersihkan semua output sebelumnya
while (ob_get_level() > 0) {
    ob_end_clean();
}

$namaFile = 'rekap_absensi.xlsx';

header(
    'Content-Type: ' .
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
);

header(
    'Content-Disposition: attachment; filename="' .
    $namaFile .
    '"'
);

header('Cache-Control: max-age=0');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: public');
header('Expires: 0');

// Buat dan kirim file XLSX asli
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');

// Bersihkan resource
$spreadsheet->disconnectWorksheets();
unset($spreadsheet);

exit;