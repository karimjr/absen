<?php
session_start();
include 'config.php';

/*
|--------------------------------------------------------------------------
| KUNCI HALAMAN (PASSWORD GATE)
|--------------------------------------------------------------------------
| Password: RM20404
| Jika sudah login -> session akan tersimpan
|
| FIX: SESSION DIBEDAKAN PER DIVISI/FOLDER
|--------------------------------------------------------------------------
*/

// ============================
// SET DIVISI (WAJIB BEDAKAN)
// ============================
// PRODUKSI:  $DIVISI = "produksi";
// WORKSHOP:  $DIVISI = "workshop";
$DIVISI = "rawmat"; // <-- GANTI DI FOLDER WORKSHOP JADI "workshop"

// password login
$PASSWORD_REKAP = "RM20404";

// session key unik per divisi
$SESSION_KEY = "rekap_admin_login_" . $DIVISI;

// proses login
if(isset($_POST['rekap_password'])){
    $pass = trim($_POST['rekap_password']);

    if($pass === $PASSWORD_REKAP){
        $_SESSION[$SESSION_KEY] = true;

        // redirect supaya POST hilang
        header("Location: admin_rekap.php");
        exit;
    }else{
        $login_error = "Password salah ❌";
    }
}

// proses logout
if(isset($_GET['logout'])){
    unset($_SESSION[$SESSION_KEY]);

    // JANGAN session_destroy() karena bisa ngerusak session divisi lain
    header("Location: admin_rekap.php");
    exit;
}

// kalau belum login -> tampilkan halaman password dulu
if(!isset($_SESSION[$SESSION_KEY]) || $_SESSION[$SESSION_KEY] !== true):
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login Rekap Absensi</title>
<style>
:root{
    --bg:#f1f5f9;
    --card:#ffffff;
    --text:#0f172a;
    --muted:#64748b;
    --border:#e2e8f0;
    --blue:#2563eb;
    --blue2:#1d4ed8;
    --shadow:0 12px 35px rgba(15,23,42,.10);
    --radius:16px;
}
*{box-sizing:border-box}
body{
    margin:0;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:22px;
    font-family:system-ui,-apple-system,Segoe UI,Roboto;
    background:var(--bg);
    color:var(--text);
}
.card{
    width:100%;
    max-width:420px;
    background:var(--card);
    padding:22px;
    border-radius:var(--radius);
    box-shadow:var(--shadow);
    border:1px solid rgba(226,232,240,.8);
}
h2{
    margin:0;
    font-size:20px;
}
p{
    margin:8px 0 18px;
    color:var(--muted);
    font-size:13px;
}
.input{
    width:100%;
    padding:12px 14px;
    border-radius:12px;
    border:1px solid var(--border);
    font-size:14px;
    outline:none;
    background:#fff;
    transition:.2s;
}
.input:focus{
    border-color:#93c5fd;
    box-shadow:0 0 0 4px rgba(37,99,235,.12);
}
.btn{
    width:100%;
    margin-top:12px;
    padding:12px 16px;
    border-radius:12px;
    border:none;
    background:var(--blue);
    color:#fff;
    cursor:pointer;
    font-size:14px;
    font-weight:700;
    transition:.2s;
}
.btn:hover{background:var(--blue2)}
.err{
    margin-top:10px;
    color:#dc2626;
    font-weight:700;
    font-size:13px;
}
.badge{
    display:inline-flex;
    align-items:center;
    gap:6px;
    background:#eff6ff;
    color:#1e40af;
    padding:7px 12px;
    border-radius:999px;
    font-size:13px;
    border:1px solid #dbeafe;
    margin-top:10px;
}
</style>
</head>
<body>
<div class="card">
    <h2>🔒 Rekap Absensi Admin (<?= strtoupper($DIVISI) ?>)</h2>
    <p>Masukkan password untuk membuka halaman rekap.</p>

    <form method="post">
        <input class="input" type="password" name="rekap_password" placeholder="Password..." required autofocus>
        <button class="btn" type="submit">Masuk</button>

        <?php if(!empty($login_error)): ?>
            <div class="err"><?= $login_error ?></div>
        <?php endif; ?>

        <div class="badge">⚡ Protected Page</div>
    </form>
</div>
</body>
</html>
<?php
exit;
endif;
// ==========================
// END LOGIN GATE
// ==========================



$search = $_GET['search'] ?? '';
$no_id  = $_GET['no_id'] ?? '';
$start  = $_GET['start'] ?? '';
$end    = $_GET['end'] ?? '';

// sort dipisah
$sort_nama    = $_GET['sort_nama'] ?? '';
$sort_tanggal = $_GET['sort_tanggal'] ?? 'desc';

/*
|--------------------------------------------------------------------------
| LIST KARYAWAN MANUAL (WAJIB DIISI)
|--------------------------------------------------------------------------
| Tambahkan semua karyawan di sini.
| Ini solusi tanpa tabel karyawan.
*/
$karyawanManual = [
    // contoh:
    // ['no_id' => '1001', 'nama' => 'Budi Santoso'],
    // ['no_id' => '1002', 'nama' => 'Andi Wijaya'],
];

// ===============================
// VALIDASI TANGGAL
// ===============================
if(!$start || !$end){
    // default 7 hari terakhir
    $end = date('Y-m-d');
    $start = date('Y-m-d', strtotime('-7 days'));
}

$startTs = strtotime($start);
$endTs   = strtotime($end);

if($startTs === false || $endTs === false){
    die("Tanggal tidak valid");
}
if($startTs > $endTs){
    // swap kalau kebalik
    $tmp = $start;
    $start = $end;
    $end = $tmp;

    $startTs = strtotime($start);
    $endTs = strtotime($end);
}

// ===============================
// AMBIL DATA ABSENSI (SQL TETAP)
// ===============================
$where = "WHERE 1";

if ($search) {
    $s = $conn->real_escape_string($search);
    $where .= " AND nama LIKE '%$s%'";
}

if ($no_id) {
    $where .= " AND no_id='".$conn->real_escape_string($no_id)."'";
}

if ($start && $end) {
    $where .= " AND DATE(waktu) BETWEEN '$start' AND '$end'";
}

// ORDER BY
$orderParts = [];

if ($sort_nama === "asc") {
    $orderParts[] = "nama ASC";
} elseif ($sort_nama === "desc") {
    $orderParts[] = "nama DESC";
}

if ($sort_tanggal === "asc") {
    $orderParts[] = "tanggal ASC";
} else {
    $orderParts[] = "tanggal DESC";
}

if (count($orderParts) === 0) {
    $orderParts[] = "tanggal DESC";
}

$order = "ORDER BY " . implode(", ", $orderParts);

$sql = "
SELECT 
    no_id,
    nama,
    DATE(waktu) AS tanggal,

    CASE DAYOFWEEK(DATE(waktu))
        WHEN 1 THEN 'Minggu'
        WHEN 2 THEN 'Senin'
        WHEN 3 THEN 'Selasa'
        WHEN 4 THEN 'Rabu'
        WHEN 5 THEN 'Kamis'
        WHEN 6 THEN 'Jumat'
        WHEN 7 THEN 'Sabtu'
    END AS hari_kode,

    MIN(CASE WHEN status='C/Masuk' THEN TIME(waktu) END) AS masuk,
    MAX(CASE WHEN status='C/Keluar' THEN TIME(waktu) END) AS keluar,
    COALESCE(NULLIF(MAX(justifikasi),''),'Normal') AS justifikasi
FROM absensi
$where
GROUP BY no_id, nama, DATE(waktu)
$order
";

$data = $conn->query($sql);

// ===============================
// BIKIN INDEX DATA ABSENSI
// key: no_id|tanggal
// ===============================
$absenMap = [];
$karyawanDariAbsensi = [];

if($data && $data->num_rows){
    while($r = $data->fetch_assoc()){
        $key = $r['no_id']."|".$r['tanggal'];
        $absenMap[$key] = $r;

        // list karyawan dari absensi
        $karyawanDariAbsensi[$r['no_id']] = $r['nama'];
    }
}

// ===============================
// GABUNG LIST KARYAWAN
// - dari absensi
// - dari manual
// ===============================
$karyawanGabungan = [];

// dari absensi
foreach($karyawanDariAbsensi as $id => $nm){
    $karyawanGabungan[$id] = $nm;
}

// dari manual
foreach($karyawanManual as $k){
    if(!isset($k['no_id'], $k['nama'])) continue;
    $karyawanGabungan[$k['no_id']] = $k['nama'];
}

// ===============================
// FILTER DI PHP (karena list gabungan)
// ===============================
if($search){
    $tmp = [];
    foreach($karyawanGabungan as $id => $nm){
        if(stripos($nm, $search) !== false){
            $tmp[$id] = $nm;
        }
    }
    $karyawanGabungan = $tmp;
}

if($no_id){
    $tmp = [];
    foreach($karyawanGabungan as $id => $nm){
        if($id == $no_id){
            $tmp[$id] = $nm;
        }
    }
    $karyawanGabungan = $tmp;
}

// ===============================
// BIKIN LIST TANGGAL
// ===============================
$tanggalList = [];
for($t = $startTs; $t <= $endTs; $t = strtotime("+1 day", $t)){
    $tanggalList[] = date('Y-m-d', $t);
}

// ===============================
// BIKIN DATA FINAL: semua karyawan x semua tanggal
// ===============================
$finalRows = [];

foreach($karyawanGabungan as $id => $nm){
    foreach($tanggalList as $tgl){

        $key = $id."|".$tgl;

        // kalau ada absensi asli
        if(isset($absenMap[$key])){
            $finalRows[] = $absenMap[$key];
            continue;
        }

        // kalau tidak ada absensi -> buat dummy row
        $dow = date('w', strtotime($tgl)); // 0=minggu

        $hariNama = [
            0 => 'Minggu',
            1 => 'Senin',
            2 => 'Selasa',
            3 => 'Rabu',
            4 => 'Kamis',
            5 => 'Jumat',
            6 => 'Sabtu'
        ][$dow];

        // DEFAULT JUSTIFIKASI:
        // - kalau Minggu => Libur
        // - selain Minggu => Alpha
        $defaultJustifikasi = ($hariNama === 'Minggu') ? 'Libur' : 'Alpha';

        $finalRows[] = [
            'no_id' => $id,
            'nama' => $nm,
            'tanggal' => $tgl,
            'hari_kode' => $hariNama,
            'masuk' => null,
            'keluar' => null,
            'justifikasi' => $defaultJustifikasi
        ];
    }
}

// ===============================
// SORT FINAL (PHP)
// ===============================
usort($finalRows, function($a, $b) use ($sort_nama, $sort_tanggal){

    // sort nama dulu kalau dipilih
    if($sort_nama){
        $cmpNama = strcasecmp($a['nama'], $b['nama']);
        if($cmpNama != 0){
            return $sort_nama === 'asc' ? $cmpNama : -$cmpNama;
        }
    }

    // sort tanggal
    $cmpTgl = strcmp($a['tanggal'], $b['tanggal']);
    if($cmpTgl != 0){
        return $sort_tanggal === 'asc' ? $cmpTgl : -$cmpTgl;
    }

    return 0;
});

// ===============================
// JAM KERJA & HITUNG TELAT / PULANG CEPAT (BARU)
// - Senin - Kamis : masuk 08:00, pulang 16:00
// - Jumat         : masuk 08:00, pulang 17:00
// - Sabtu         : masuk 08:00, pulang 13:00
// - Minggu        : libur (tidak dihitung)
// ===============================
function jamKerja($hari){
    if($hari === 'Jumat'){
        return ['masuk' => '08:00:00', 'keluar' => '17:00:00'];
    }
    if($hari === 'Sabtu'){
        return ['masuk' => '08:00:00', 'keluar' => '13:00:00'];
    }
    if($hari === 'Minggu'){
        return null; // libur, tidak ada jam kerja
    }
    // Senin - Kamis
    return ['masuk' => '08:00:00', 'keluar' => '16:00:00'];
}

function hitungTelatCepat($hari, $masuk, $keluar){
    $result = [
        'telat_menit' => null,
        'cepat_menit' => null,
        'telat_flag'  => false,
        'cepat_flag'  => false,
    ];

    $jam = jamKerja($hari);
    if($jam === null){
        return $result; // hari libur, tidak dihitung
    }

    if(!empty($masuk)){
        $diff = (strtotime($masuk) - strtotime($jam['masuk'])) / 60;
        if($diff > 0){
            $result['telat_menit'] = (int) round($diff);
            $result['telat_flag']  = true;
        }
    }

    if(!empty($keluar)){
        $diff = (strtotime($jam['keluar']) - strtotime($keluar)) / 60;
        if($diff > 0){
            $result['cepat_menit'] = (int) round($diff);
            $result['cepat_flag']  = true;
        }
    }

    return $result;
}

$no = 1;
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Rekap Absensi Admin</title>

<style>
:root{
    --bg:#f1f5f9;
    --card:#ffffff;
    --text:#0f172a;
    --muted:#64748b;
    --border:#e2e8f0;
    --blue:#2563eb;
    --blue2:#1d4ed8;
    --shadow:0 12px 35px rgba(15,23,42,.10);
    --radius:16px;
}

*{box-sizing:border-box}
body{
    margin:0;
    padding:22px;
    font-family:system-ui,-apple-system,Segoe UI,Roboto;
    background:var(--bg);
    color:var(--text);
}

.container{
    max-width:1400px;
    margin:auto;
}

.card{
    background:var(--card);
    padding:20px;
    border-radius:var(--radius);
    box-shadow:var(--shadow);
    border:1px solid rgba(226,232,240,.8);
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:15px;
    flex-wrap:wrap;
    margin-bottom:14px;
}

.title h2{
    margin:0;
    font-size:22px;
    letter-spacing:.2px;
}

.title p{
    margin:4px 0 0;
    color:var(--muted);
    font-size:13px;
}

.badge{
    display:inline-flex;
    align-items:center;
    gap:6px;
    background:#eff6ff;
    color:#1e40af;
    padding:7px 12px;
    border-radius:999px;
    font-size:13px;
    border:1px solid #dbeafe;
}

.filter{
    display:grid;
    grid-template-columns: 160px 160px 1fr 1fr 180px 180px auto auto;
    gap:10px;
    margin-bottom:16px;
    align-items:end;
}

.filter label{
    display:block;
    font-size:12px;
    color:var(--muted);
    margin-bottom:5px;
}

.input{
    width:100%;
    padding:10px 12px;
    border-radius:12px;
    border:1px solid var(--border);
    font-size:14px;
    outline:none;
    background:#fff;
    transition:.2s;
}

.input:focus{
    border-color:#93c5fd;
    box-shadow:0 0 0 4px rgba(37,99,235,.12);
}

.btn{
    padding:10px 16px;
    border-radius:12px;
    border:none;
    background:var(--blue);
    color:#fff;
    cursor:pointer;
    font-size:14px;
    text-decoration:none;
    font-weight:600;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    transition:.2s;
    white-space:nowrap;
}

.btn:hover{background:var(--blue2)}
.btn.secondary{background:#0f172a}
.btn.secondary:hover{opacity:.9}

.btn.light{
    background:#f1f5f9;
    color:#0f172a;
    border:1px solid var(--border);
}
.btn.light:hover{background:#e2e8f0}

.table-wrap{
    overflow:auto;
    border-radius:14px;
    border:1px solid var(--border);
}

table{
    width:100%;
    border-collapse:collapse;
    font-size:14px;
    min-width:1450px;
}

thead th{
    background:linear-gradient(180deg,#2563eb,#1d4ed8);
    color:#fff;
    padding:13px 12px;
    text-align:left;
    font-weight:700;
    position:sticky;
    top:0;
    z-index:5;
    white-space:nowrap;
}

tbody td{
    padding:12px;
    border-bottom:1px solid #eef2f7;
    vertical-align:top;
}

tbody tr:hover{background:#f8fafc}
.text-center{text-align:center}
.muted{color:var(--muted)}

.time-pill{
    display:inline-flex;
    padding:5px 10px;
    border-radius:999px;
    background:#f1f5f9;
    border:1px solid #e2e8f0;
    font-variant-numeric:tabular-nums;
    font-size:13px;
}

.time-pill.in{
    background:#ecfdf5;
    border-color:#bbf7d0;
    color:#166534;
}
.time-pill.out{
    background:#fff7ed;
    border-color:#fed7aa;
    color:#9a3412;
}

/* MASUK TELAT / PULANG CEPAT -> MERAH (BARU) */
.time-pill.in.telat{
    background:#ffedd5;
    border-color:#f97316;
    color:#9a3412;
    font-weight:700;
}
.time-pill.out.cepat{
    background:#ffedd5;
    border-color:#f97316;
    color:#9a3412;
    font-weight:700;
}

/* BADGE MENIT TELAT / CEPAT (BARU) */
.menit-badge{
    display:inline-flex;
    align-items:center;
    gap:4px;
    padding:5px 10px;
    border-radius:999px;
    background:#ffedd5;
    border:1px solid #f97316;
    color:#9a3412;
    font-weight:700;
    font-size:13px;
    white-space:nowrap;
}

/* BADGE MINGGU (MERAH) */
.hari-minggu{
    color:#dc2626;
    font-weight:800;
    background:#fef2f2;
    border:1px solid #fecaca;
    padding:5px 10px;
    border-radius:999px;
    display:inline-flex;
    align-items:center;
    gap:6px;
}

.j-wrap{
    display:flex;
    flex-direction:column;
    gap:8px;
}

.j-select{
    width:100%;
    padding:10px 12px;
    border-radius:12px;
    border:1px solid #e2e8f0;
    font-size:14px;
    outline:none;
    background:#fff;
    transition:.2s;
}

.j-select:focus{
    border-color:#93c5fd;
    box-shadow:0 0 0 4px rgba(37,99,235,.12);
}

.j-input{
    width:100%;
    padding:10px 12px;
    border-radius:12px;
    border:1px solid #e2e8f0;
    font-size:14px;
    outline:none;
    background:#fff;
    transition:.2s;
    display:none;
}

.j-input:focus{
    border-color:#93c5fd;
    box-shadow:0 0 0 4px rgba(37,99,235,.12);
}

.saving{
    border-color:#fbbf24 !important;
}
.saved{
    border-color:#22c55e !important;
}

.save-info{
    font-size:12px;
}

.footer{
    margin-top:14px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:10px;
    color:var(--muted);
    font-size:13px;
}

.loading{
    display:none;
    align-items:center;
    gap:8px;
    color:var(--muted);
}
.loading span{
    width:10px;height:10px;border-radius:50%;
    background:#94a3b8;
    display:inline-block;
    animation:bounce .9s infinite alternate;
}
.loading span:nth-child(2){animation-delay:.15s}
.loading span:nth-child(3){animation-delay:.3s}
@keyframes bounce{
    from{transform:translateY(0); opacity:.5}
    to{transform:translateY(-6px); opacity:1}
}

@media(max-width:1100px){
    .filter{grid-template-columns: 1fr 1fr;}
}

/* =====================================================
   WARNA JUSTIFIKASI (BARU)
   ===================================================== */
.j-select.j-normal, .j-input.j-normal{
    background:#f1f5f9;
    border-color:#cbd5e1;
    color:#0f172a;
}

.j-select.j-sakit, .j-input.j-sakit{
    background:#fef9c3;
    border-color:#facc15;
    color:#854d0e;
}

.j-select.j-izin, .j-input.j-izin{
    background:#a5f3fc;
    border-color:#06b6d4;
    color:#155e75;
    font-weight:700;
}

.j-select.j-alpha, .j-input.j-alpha{
    background:#dc2626;
    border-color:#7f1d1d;
    color:#ffffff;
    font-weight:800;
}

.j-select.j-dinas, .j-input.j-dinas{
    background:#f3e8ff;
    border-color:#a855f7;
    color:#6b21a8;
}

.j-select.j-libur, .j-input.j-libur{
    background:#dcfce7;
    border-color:#22c55e;
    color:#166534;
    font-weight:700;
}

.j-select.j-cuti, .j-input.j-cuti{
    background:#dbeafe;
    border-color:#3b82f6;
    color:#1e3a8a;
    font-weight:700;
}

.j-select.j-lainnya, .j-input.j-lainnya{
    background:#e0e7ff;
    border-color:#6366f1;
    color:#3730a3;
    font-weight:700;
}

.j-select.j-telat, .j-input.j-telat,
.j-select.j-pulangcepat, .j-input.j-pulangcepat,
.j-select.j-telatcepat, .j-input.j-telatcepat{
    background:#ffedd5;
    border-color:#f97316;
    color:#9a3412;
    font-weight:700;
}
</style>
</head>

<body>
<div class="container">
<div class="card">

    <div class="header">
        <div class="title">
            <h2>📋 Rekap Absensi Admin (<?= strtoupper($DIVISI) ?>)</h2>
            <p>Auto cari No ID / Nama tanpa klik tombol. Tanggal tetap pakai tombol.</p>
        </div>

        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
            <div class="badge">⚡ Justifikasi Dropdown</div>
            <a href="admin_rekap.php?logout=1" class="btn light">🚪 Logout</a>
        </div>
    </div>

    <form method="get" id="filterForm" class="filter">

        <div>
            <label>Dari Tanggal</label>
            <input class="input" type="date" name="start" id="start" value="<?=$start?>">
        </div>

        <div>
            <label>Sampai Tanggal</label>
            <input class="input" type="date" name="end" id="end" value="<?=$end?>">
        </div>

        <div>
            <label>No ID (auto)</label>
            <input class="input" type="text" name="no_id" id="no_id" placeholder="Contoh: 10012" value="<?=$no_id?>">
        </div>

        <div>
            <label>Nama (auto)</label>
            <input class="input" type="text" name="search" id="search" placeholder="Contoh: Abdul" value="<?=$search?>">
        </div>

        <div>
            <label>Urut Nama</label>
            <select class="input" name="sort_nama" id="sort_nama">
                <option value="" <?= $sort_nama==''?'selected':'' ?>>-</option>
                <option value="asc" <?= $sort_nama=='asc'?'selected':'' ?>>Nama A-Z</option>
                <option value="desc" <?= $sort_nama=='desc'?'selected':'' ?>>Nama Z-A</option>
            </select>
        </div>

        <div>
            <label>Urut Tanggal</label>
            <select class="input" name="sort_tanggal" id="sort_tanggal">
                <option value="desc" <?= $sort_tanggal=='desc'?'selected':'' ?>>Terbaru ↓</option>
                <option value="asc" <?= $sort_tanggal=='asc'?'selected':'' ?>>Terlama ↑</option>
            </select>
        </div>

        <button type="submit" class="btn" id="btnTanggal">📅 Terapkan Tanggal</button>
        <a href="admin_rekap.php" class="btn light">♻ Reset</a>

        <div style="grid-column:1/-1; display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap;">
            <a href="export_excel.php?<?=http_build_query($_GET)?>" class="btn secondary">⬇ Export Excel</a>

            <div class="loading" id="loading">
                <span></span><span></span><span></span>
                <b>Memuat...</b>
            </div>
        </div>
    </form>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th style="width:60px" class="text-center">No</th>
                    <th>No ID</th>
                    <th>Nama</th>
                    <th>Tanggal</th>
                    <th>Hari</th>
                    <th>Masuk</th>
                    <th>Keluar</th>
                    <th class="text-center">Telat (menit)</th>
                    <th class="text-center">Pulang Cepat (menit)</th>
                    <th style="min-width:360px;">Justifikasi</th>
                </tr>
            </thead>

            <tbody>
            <?php if(count($finalRows)): ?>
                <?php foreach($finalRows as $r): ?>
                <?php
                    $j = trim($r['justifikasi'] ?? 'Normal');

                    // HITUNG TELAT / PULANG CEPAT (BARU)
                    $tc = hitungTelatCepat($r['hari_kode'], $r['masuk'], $r['keluar']);

                    // OTOMATIS: kalau justifikasi masih "Normal" (belum ada override manual)
                    // tapi ternyata telat / pulang cepat -> otomatis ganti jadi Telat / Pulang Cepat
                    if($j === 'Normal' && ($tc['telat_flag'] || $tc['cepat_flag'])){
                        if($tc['telat_flag'] && $tc['cepat_flag']){
                            $j = 'Telat & Pulang Cepat';
                        } elseif($tc['telat_flag']){
                            $j = 'Telat';
                        } else {
                            $j = 'Pulang Cepat';
                        }
                    }

                    // OPSI DROPDOWN
                    $ops = ['Normal','Sakit','Izin','Alpha','Dinas','Libur','Cuti','Telat','Pulang Cepat','Telat & Pulang Cepat'];

                    $selected = in_array($j, $ops) ? $j : 'Lainnya';
                    $lainnyaVal = ($selected === 'Lainnya') ? $j : '';
                ?>
                <tr>
                    <td class="text-center"><?=$no++?></td>
                    <td><b><?=$r['no_id']?></b></td>
                    <td><?=$r['nama']?></td>
                    <td><?=date('d-m-Y', strtotime($r['tanggal']))?></td>

                    <td>
                        <?php if($r['hari_kode'] === 'Minggu'): ?>
                            <span class="hari-minggu">🔴 <?=$r['hari_kode']?></span>
                        <?php else: ?>
                            <b><?=$r['hari_kode']?></b>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if($r['masuk']): ?>
                            <span class="time-pill in <?= $tc['telat_flag'] ? 'telat' : '' ?>"><?=$r['masuk']?></span>
                        <?php else: ?>
                            <span class="muted">-</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if($r['keluar']): ?>
                            <span class="time-pill out <?= $tc['cepat_flag'] ? 'cepat' : '' ?>"><?=$r['keluar']?></span>
                        <?php else: ?>
                            <span class="muted">-</span>
                        <?php endif; ?>
                    </td>

                    <td class="text-center">
                        <?php if($tc['telat_flag']): ?>
                            <span class="menit-badge">⏰ <?=$tc['telat_menit']?> mnt</span>
                        <?php else: ?>
                            <span class="muted">-</span>
                        <?php endif; ?>
                    </td>

                    <td class="text-center">
                        <?php if($tc['cepat_flag']): ?>
                            <span class="menit-badge">⏰ <?=$tc['cepat_menit']?> mnt</span>
                        <?php else: ?>
                            <span class="muted">-</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <div class="j-wrap"
                            data-noid="<?=$r['no_id']?>"
                            data-tanggal="<?=$r['tanggal']?>"
                        >
                            <select class="j-select">
                                <option value="Normal" <?=$selected=='Normal'?'selected':''?>>Normal</option>
                                <option value="Sakit" <?=$selected=='Sakit'?'selected':''?>>Sakit</option>
                                <option value="Izin" <?=$selected=='Izin'?'selected':''?>>Izin</option>
                                <option value="Alpha" <?=$selected=='Alpha'?'selected':''?>>Alpha</option>
                                <option value="Dinas" <?=$selected=='Dinas'?'selected':''?>>Dinas</option>
                                <option value="Libur" <?=$selected=='Libur'?'selected':''?>>Libur</option>
                                <option value="Cuti" <?=$selected=='Cuti'?'selected':''?>>Cuti</option>
                                <option value="Telat" <?=$selected=='Telat'?'selected':''?>>Telat</option>
                                <option value="Pulang Cepat" <?=$selected=='Pulang Cepat'?'selected':''?>>Pulang Cepat</option>
                                <option value="Telat & Pulang Cepat" <?=$selected=='Telat & Pulang Cepat'?'selected':''?>>Telat & Pulang Cepat</option>
                                <option value="Lainnya" <?=$selected=='Lainnya'?'selected':''?>>Lainnya (isi manual)</option>
                            </select>

                            <input type="text"
                                class="j-input"
                                placeholder="Isi justifikasi lainnya..."
                                value="<?=htmlspecialchars($lainnyaVal)?>"
                            >

                            <div class="save-info muted"></div>
                        </div>
                    </td>
                </tr>
                <?php endforeach ?>
            <?php else: ?>
                <tr>
                    <td colspan="10" class="text-center muted" style="padding:18px;">
                        Data tidak ditemukan
                    </td>
                </tr>
            <?php endif ?>
            </tbody>
        </table>
    </div>

    <div class="footer">
        <div>💡 Tips: No ID / Nama auto. Justifikasi auto save.</div>
        <div>Total data: <b><?= count($finalRows) ?></b></div>
    </div>

</div>
</div>

<script>
(function(){
    const form = document.getElementById('filterForm');
    const no_id = document.getElementById('no_id');
    const search = document.getElementById('search');

    const sort_nama = document.getElementById('sort_nama');
    const sort_tanggal = document.getElementById('sort_tanggal');

    const loading = document.getElementById('loading');

    let typingTimer;

    function submitAuto(){
        loading.style.display = "inline-flex";
        clearTimeout(typingTimer);
        typingTimer = setTimeout(() => {
            form.submit();
        }, 450);
    }

    no_id.addEventListener('input', submitAuto);
    search.addEventListener('input', submitAuto);

    sort_nama.addEventListener('change', submitAuto);
    sort_tanggal.addEventListener('change', submitAuto);

    function saveJustifikasi(wrap, value){
        const noid = wrap.dataset.noid;
        const tanggal = wrap.dataset.tanggal;

        const select = wrap.querySelector('.j-select');
        const input = wrap.querySelector('.j-input');
        const info = wrap.querySelector('.save-info');

        select.classList.add('saving');
        input.classList.add('saving');
        info.textContent = "Menyimpan...";

        const fd = new FormData();
        fd.append("no_id", noid);
        fd.append("tanggal", tanggal);
        fd.append("justifikasi", value);

        fetch("update_justifikasi.php", {
            method: "POST",
            body: fd
        })
        .then(r => r.json())
        .then(res => {
            select.classList.remove('saving');
            input.classList.remove('saving');

            if(res.status === "success"){
                select.classList.add('saved');
                input.classList.add('saved');
                info.textContent = "Tersimpan ✔";

                setTimeout(()=>{
                    select.classList.remove('saved');
                    input.classList.remove('saved');
                    info.textContent = "";
                }, 1500);
            }else{
                info.textContent = "Gagal menyimpan ❌";
            }
        })
        .catch(()=>{
            select.classList.remove('saving');
            input.classList.remove('saving');
            info.textContent = "Error jaringan ❌";
        });
    }

    document.querySelectorAll('.j-wrap').forEach((wrap) => {
        const select = wrap.querySelector('.j-select');
        const input = wrap.querySelector('.j-input');

        function applyWarna(){
            const val = select.value;

            // reset class warna
            select.classList.remove("j-normal","j-sakit","j-izin","j-alpha","j-dinas","j-libur","j-cuti","j-lainnya","j-telat","j-pulangcepat","j-telatcepat");
            input.classList.remove("j-normal","j-sakit","j-izin","j-alpha","j-dinas","j-libur","j-cuti","j-lainnya","j-telat","j-pulangcepat","j-telatcepat");

            if(val === "Normal") { select.classList.add("j-normal"); input.classList.add("j-normal"); }
            else if(val === "Sakit") { select.classList.add("j-sakit"); input.classList.add("j-sakit"); }
            else if(val === "Izin") { select.classList.add("j-izin"); input.classList.add("j-izin"); }
            else if(val === "Alpha") { select.classList.add("j-alpha"); input.classList.add("j-alpha"); }
            else if(val === "Dinas") { select.classList.add("j-dinas"); input.classList.add("j-dinas"); }
            else if(val === "Libur") { select.classList.add("j-libur"); input.classList.add("j-libur"); }
            else if(val === "Cuti") { select.classList.add("j-cuti"); input.classList.add("j-cuti"); }
            else if(val === "Telat") { select.classList.add("j-telat"); input.classList.add("j-telat"); }
            else if(val === "Pulang Cepat") { select.classList.add("j-pulangcepat"); input.classList.add("j-pulangcepat"); }
            else if(val === "Telat & Pulang Cepat") { select.classList.add("j-telatcepat"); input.classList.add("j-telatcepat"); }
            else if(val === "Lainnya") { select.classList.add("j-lainnya"); input.classList.add("j-lainnya"); }
        }

        function toggleInput(){
            if(select.value === "Lainnya"){
                input.style.display = "block";
                input.focus();
            }else{
                input.style.display = "none";
                input.value = "";
            }
        }

        toggleInput();
        applyWarna();

        select.addEventListener('change', () => {
            toggleInput();
            applyWarna();

            if(select.value === "Lainnya"){
                return;
            }
            saveJustifikasi(wrap, select.value);
        });

        let timer;
        input.addEventListener('input', () => {
            clearTimeout(timer);

            timer = setTimeout(() => {
                const v = input.value.trim();
                saveJustifikasi(wrap, v ? v : "Normal");
            }, 600);
        });
    });

})();
</script>

</body>
</html>