<?php
$conn = new mysqli("localhost", "potensib_pbs", "arsari-group", "potensib_absen_hse");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
