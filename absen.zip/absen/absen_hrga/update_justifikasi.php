<?php
// update_justifikasi.php
header('Content-Type: application/json');

session_start();
include 'config.php';

/*
|--------------------------------------------------------------------------
| VERIFIKASI SESSION (FIX)
|--------------------------------------------------------------------------
| Karena di admin_rekap.php menggunakan session_key dinamis:
| "rekap_admin_login_produksi" atau "rekap_admin_login_workshop"
| Maka kita harus mengecek pola tersebut.
*/
$is_logged_in = false;
foreach ($_SESSION as $key => $value) {
    if (strpos($key, 'rekap_admin_login_') === 0 && $value === true) {
        $is_logged_in = true;
        break;
    }
}

if (!$is_logged_in) {
    echo json_encode([
        "status" => "error",
        "msg" => "Unauthorized - Silakan login kembali"
    ]);
    exit;
}

// Ambil data POST
$no_id       = trim($_POST['no_id'] ?? '');
$tanggal     = trim($_POST['tanggal'] ?? '');
$justifikasi = trim($_POST['justifikasi'] ?? '');

// Validasi input dasar
if ($no_id === '' || $tanggal === '') {
    echo json_encode([
        "status" => "error",
        "msg" => "Data tidak lengkap"
    ]);
    exit;
}

// Jika kosong, set default ke Normal
if ($justifikasi === '') {
    $justifikasi = "Normal";
}

// Validasi format tanggal
$ts = strtotime($tanggal);
if ($ts === false) {
    echo json_encode([
        "status" => "error",
        "msg" => "Format tanggal tidak valid"
    ]);
    exit;
}
$tanggalFix = date('Y-m-d', $ts);

// ============================================================
// STEP 1: COBA UPDATE DULU
// ============================================================
// Kita update semua record pada tanggal tersebut untuk ID tsb
$stmt = $conn->prepare("
    UPDATE absensi 
    SET justifikasi = ? 
    WHERE no_id = ? AND DATE(waktu) = ?
");
$stmt->bind_param("sss", $justifikasi, $no_id, $tanggalFix);
$stmt->execute();

$affected = $stmt->affected_rows;
$stmt->close();

// ============================================================
// STEP 2: JIKA TIDAK ADA YANG TER-UPDATE (DUMMY ROW)
// ============================================================
if ($affected <= 0) {
    
    // 1. Cari nama karyawan terakhir agar data dummy tidak 'Unknown'
    $namaKaryawan = 'Karyawan'; 
    $stmtNama = $conn->prepare("
        SELECT nama FROM absensi 
        WHERE no_id = ? 
        ORDER BY waktu DESC LIMIT 1
    ");
    $stmtNama->bind_param("s", $no_id);
    $stmtNama->execute();
    $resNama = $stmtNama->get_result();
    if ($resNama && $resNama->num_rows > 0) {
        $rowNama = $resNama->fetch_assoc();
        $namaKaryawan = $rowNama['nama'];
    }
    $stmtNama->close();

    // 2. Insert data baru sebagai record "Manual" atau "Dummy"
    // Jam diset 00:00:00 agar tidak merusak perhitungan jam kerja asli
    $waktuDummy = $tanggalFix . " 00:00:00";
    $statusDummy = "Manual";

    $stmtInsert = $conn->prepare("
        INSERT INTO absensi (no_id, nama, waktu, status, justifikasi) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmtInsert->bind_param("sssss", $no_id, $namaKaryawan, $waktuDummy, $statusDummy, $justifikasi);
    
    if ($stmtInsert->execute()) {
        echo json_encode(["status" => "success", "msg" => "Data dummy berhasil ditambahkan"]);
    } else {
        echo json_encode(["status" => "error", "msg" => "Gagal menyimpan: " . $conn->error]);
    }
    $stmtInsert->close();

} else {
    // Berhasil update data yang memang sudah ada
    echo json_encode(["status" => "success", "msg" => "Justifikasi berhasil diperbarui"]);
}

exit;